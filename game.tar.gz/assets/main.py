# -*- coding: utf-8 -*-
"""
TÂN TOWER DEFENSE - Game tower defense 2D bằng Python + Pygame
========================================================================================
Chạy PC  : python main.py
Build Web: python -X utf8 -m pygbag .
"""
import os
import sys
import math
import random
import pygame
import asyncio

# ----------------------------------------------------------------------------
# CẤU HÌNH CƠ BẢN
# ----------------------------------------------------------------------------
W, H = 1200, 720
CELL = 60
COLS, ROWS = 16, 9
MAP_W, MAP_H = COLS * CELL, ROWS * CELL          # 960 x 540
PANEL_X = MAP_W

START_GOLD = 100
START_GEMS = 5
START_BASE_HP = 20
BASE_ROLL_COST = 20
ENCHANT_COST = 2          # đá phù phép
MAX_STAGE = 30
MAX_LEVEL = 4
BENCH_SIZE = 12           # Kho đồ 12 ô
SLOT = 58
ICON = 52
HP_SCALE_PER_STAGE = 1.15
MAX_UNITS_PER_TYPE_ON_BOARD = 4

# Đường dẫn tuyệt đối chuẩn cho cả PC và WebAssembly
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
for _d in ("units", "enemies", "bg", "fonts"):
    os.makedirs(os.path.join(ASSET_DIR, _d), exist_ok=True)

# Đường đi của quái (toạ độ ô: cột, hàng).
WAYPOINTS = [(0, 1), (13, 1), (13, 4), (2, 4), (2, 7), (15, 7)]

# ----------------------------------------------------------------------------
# CODES HỆ THỐNG
# ----------------------------------------------------------------------------
CODES_REWARDS = {
    # 500 Vàng
    "+500G": ("gold", 500), "EjXoe": ("gold", 500), "MfnE#": ("gold", 500), ")ksL2": ("gold", 500),
    "MF_$(": ("gold", 500), "MCX)(": ("gold", 500), "DSexC": ("gold", 500), "%)(FD": ("gold", 500),
    "T3S5)": ("gold", 500), "sDJK)": ("gold", 500), "VU@$(" : ("gold", 500), "Ddk(@": ("gold", 500),
    "FOD_(": ("gold", 500), "M$eO)": ("gold", 500), "@NF(.": ("gold", 500), "Nen2x": ("gold", 500),
    "NF943": ("gold", 500), "o69sN": ("gold", 500), "4n328": ("gold", 500),
    # 10 Đá Phù Phép
    "+10Eg": ("gems", 10), "2nd9c": ("gems", 10), "gnd0D": ("gems", 10), "dfn72": ("gems", 10),
    "mvb0w": ("gems", 10), "EMhvx": ("gems", 10), "o)&2f": ("gems", 10), "Nv9xc": ("gems", 10),
    "znaWn": ("gems", 10), "F)2.s": ("gems", 10), "vceE8": ("gems", 10), "0(!NC": ("gems", 10),
    "4=D@K": ("gems", 10), "dsmEx": ("gems", 10), "-xzk2": ("gems", 10),
    # 1 Khánh Duy LV1
    "8===D": ("unit_kd", 1), "2nX)(": ("unit_kd", 1), "23mfd": ("unit_kd", 1), "C92nE": ("unit_kd", 1),
    "NxIEm": ("unit_kd", 1), "mAxJE": ("unit_kd", 1), "9341w": ("unit_kd", 1), "cn483": ("unit_kd", 1),
    "En29&": ("unit_kd", 1),
    # 1 Khánh Duy LV4
    "P2wEz": ("unit_kd", 4),
}

# ----------------------------------------------------------------------------
# DỮ LIỆU TƯỚNG
# ----------------------------------------------------------------------------
RARITIES = [
    ("Thường", 50, (200, 200, 200)),
    ("Hiếm", 30, (80, 160, 255)),
    ("Sử thi", 18, (190, 90, 255)),
    ("Huyền thoại", 2, (255, 170, 40)),
]

UNITS = [
    # Thường (r=0)
    dict(id="an", name="An", r=0, dmg=7, range=160, cd=1.0,
         color=(80, 200, 120), desc="Bắn nước bọt xanh. LV4 Passive: Xả khói độc 2s gây 10 DPS (CD 20s)"),
    dict(id="tuan_loc", name="Tuần Lộc", r=0, dmg=12, range=100, cd=0.75,
         color=(200, 140, 90), desc="Võ tuần lộc. LV4 Passive: Biến 1 quái thành Tuần Lộc gây 10 DPS (CD 20s)"),
    dict(id="hai_duong", name="Hải Dương", r=0, dmg=0, range=0, cd=99.0, wall_hp=15, place_on_path=True, no_upgrade=True, no_enchant=True,
         color=(150, 150, 150), desc="Đặt TRÊN ĐƯỜNG CHẶN ĐỊCH (15 HP). Không thể phù phép."),
    dict(id="hayuu", name="Hayuu", r=0, dmg=1, range=120, cd=2.0,
         color=(100, 220, 200), desc="Làm đứng im N Tân (N=Cấp) trong 1.5s & gây 1 dmg. LV4 Passive: Làm đứng im toàn bộ Tân 1s (CD 20s)"),
    dict(id="bach_toan", name="Bách Toán", r=0, dmg=15, range=80, cd=0.75, custom_upgrade=True,
         color=(180, 180, 100), desc="+2 Dmg & -0.15s CD mỗi cấp. LV4 Passive: Đòn thứ 5 gây x2 sát thương!"),
    
    # Hiếm (r=1)
    dict(id="truong", name="Trường", r=1, dmg=10, range=140, cd=2.0,
         color=(240, 240, 240), desc="AOE trắng 2 ô gây 10 DPS & làm chậm 50% trong 1s. LV4 Active: CD 0.5s trong 5s (CD 20s)"),
    dict(id="minh_duc", name="Minh Đức", r=1, dmg=0, range=0, cd=99.0, gold_gen=[50, 75, 113, 150], no_enchant=True,
         color=(255, 215, 0), desc="Cộng thêm vàng đầu màn. Tối đa 4 trên bản đồ. Không thể phù phép."),
    dict(id="minh_thai", name="Minh Thái", r=1, dmg=0, range=0, cd=99.0, no_enchant=True,
         color=(160, 220, 100), desc="Buff dame 4 ô xung quanh (+10/12/15/20%). LV4 Passive: Hồi chiêu skill 2 ô Trái/Phải (CD 45s)."),
    dict(id="gia_nam", name="Gia Nam", r=1, dmg=10, range=100, cd=0.6, aoe=True,
         color=(139, 69, 19), desc="Tấn công đá đa mục tiêu 1 ô. LV4 Passive: 20% hụt, 50% x2 dame"),
    dict(id="khoa_nguyen", name="Khoa Nguyên", r=1, dmg=5, range=100, cd=1.0, knockback=1,
         color=(100, 150, 200), desc="Tấn công đẩy lùi địch 1 ô. LV4 Passive: 50% cơ hội đẩy lùi ô địch đi 2 ô (CD 30s)"),
    dict(id="chan_hung", name="Chấn Hưng", r=1, dmg=999, range=100, cd=10.0, execute_hp=100,
         color=(180, 40, 40), desc="Nuốt quái <100 HP (CD 10s). LV4 Passive: Tầm 200, nuốt 100 HP quái trâu nhất (CD 20s)"),
    dict(id="bao_nam", name="Bảo Nam", r=1, dmg=5, range=140, cd=1.0,
         color=(255, 140, 200), desc="Bắn liên tiếp 3 OSU circle trong 0.5s. LV4 Passive: Xoay Visual Wheel 5s gây 10 DPS toàn vùng (CD 20s)"),

    # Sử thi (r=2)
    dict(id="huy_duc", name="Huy Đức", r=2, dmg=15, range=140, cd=1.0,
         color=(120, 80, 200), desc="Ném cờ vua ngẫu nhiên. LV4 Active: Triệu hồi Vua đi từ nhà về cổng gây 10 DPS (CD 20s khi xong)"),
    dict(id="duy_anh", name="Duy Anh", r=2, dmg=0, range=100, cd=1.0, no_enchant=True,
         color=(255, 105, 180), desc="Buff đồng minh trong phạm vi (+10% dame/tầm mỗi cấp). LV4 Active: Toàn bản đồ +20% dame/tầm, -20% CD (CD 30s)"),
    dict(id="anh_ngoc", name="Anh Ngọc", r=2, dmg=15, range=100, cd=1.0,
         color=(255, 230, 50), desc="Bắn sét lan bán kính 30px. LV4 Active: Búa Thor giáng sét toàn map 75 dmg + 5 DPS & làm chậm 20% 5s (CD 60s)"),
    dict(id="tien_quan", name="Tiến Quân", r=2, dmg=25, range=120, cd=1.25,
         color=(50, 180, 255), desc="Sút bóng làm chậm 30% trong 0.75s. LV4 Passive: Mỗi 20s sút bóng nổ bán kính 100px, 40 dmg"),
    dict(id="hoang_hai", name="Hoàng Hải", r=2, dmg=20, range=140, cd=1.5,
         color=(230, 80, 120), desc="Tấn công nổ 3 ô gây 20 dmg. LV4 Passive: +1 Vàng mỗi quái diệt. LV4 Active: Làm choáng Tân gầy 1s (CD 10s)"),

    # Huyền thoại (r=3)
    dict(id="khanh_duy", name="Khánh Duy", r=3, dmg=15, range=160, cd=0.5, aura_dmg=True,
         color=(255, 215, 0), desc="Aura hào quang gây 15 dmg mỗi 0.5s cho TẤT CẢ địch trong tầm. LV4 Active: Thu phục quái <1000 HP (CD 30s)"),
]
UNIT_BY_ID = {u["id"]: u for u in UNITS}

# ----------------------------------------------------------------------------
# PHÙ PHÉP
# ----------------------------------------------------------------------------
ENCHANTS = {
    "fire": ("Hỏa ấn", (255, 110, 40), "H", "Thiêu đốt kẻ địch 3 giây"),
    "ice": ("Băng ấn", (110, 220, 255), "B", "Làm chậm 40% trong 1.5 giây"),
    "thunder": ("Lôi ấn", (255, 240, 90), "L", "Sét lan sang 2 kẻ địch gần đó"),
    "haste": ("Cuồng tốc", (120, 255, 140), "T", "Tốc độ đánh +50%"),
    "power": ("Cuồng lực", (255, 90, 120), "S", "Sát thương +50%"),
    "greed": ("Tham lam", (255, 215, 0), "V", "Hạ quái nhận thêm 3 vàng"),
}

# ----------------------------------------------------------------------------
# QUÁI (Đã đổi tên lịch sự & cập nhật hiệu ứng)
# ----------------------------------------------------------------------------
ENEMIES = {
    "ngoc_tan_phe": dict(name="Tân thường", hp=50, speed=60, gold=4, dmg=1, color=(180, 120, 120), size=14, desc="Quái cơ bản, yếu ớt"),
    "ngoc_tan_nhanh": dict(name="Tân nhanh", hp=30, speed=120, gold=4, dmg=1, color=(240, 170, 60), size=12, desc="Tốc độ cao 120, chết hóa Tân thường"),
    "ngoc_tan_trau": dict(name="Tân trâu", hp=120, speed=65, gold=5, dmg=3, color=(110, 110, 150), size=18, desc="Máu trâu 120 HP, gây 3 sát thương nhà"),
    "ngoc_tan_pha_game": dict(name="Tân phá", hp=150, speed=65, gold=6, dmg=2, color=(200, 50, 50), size=16, desc="Tỉ lệ 20% mỗi 2s gây choáng 1 tướng gần nhất 3s"),
    "ngoc_tan_cho_dien": dict(name="Tân Flash", hp=100, speed=80, gold=5, dmg=5, color=(220, 50, 150), size=15, desc="Khi máu dưới 50 tốc độ bộc phát thành 160!"),
    "ngoc_tan_suc_vat": dict(name="Tân mạnh", hp=500, speed=60, gold=7, dmg=4, color=(100, 50, 200), size=22, desc="Siêu trâu bò 500 HP, gây 4 sát thương nhà"),
    "ngoc_tan_lo": dict(name="Tân stun", hp=50, speed=60, gold=4, dmg=1, color=(80, 200, 200), size=14, desc="Gây choáng 1s tướng gần nhất mỗi 5s, chết hóa Tân thường"),
    "ngoc_tan_rac": dict(name="Tân yếu", hp=1, speed=100, gold=2, dmg=100, color=(150, 150, 150), size=10, desc="Chỉ 1 HP nhưng gây 100 sát thương nhà!"),
    "ngoc_tan_gay": dict(name="Tân gầy", hp=100, speed=100, gold=5, dmg=1, color=(255, 105, 180), size=14, desc="Buff +50% tốc chạy cho Tân khác trong 1 ô"),
    "ngoc_tan_nhan_ban": dict(name="Tân nhân bản", hp=50, speed=60, gold=4, dmg=1, color=(120, 200, 120), size=14, desc="Hạ gục tách làm 2 bản thể con 1/2 máu, +5 tốc"),
    "64x_ngoc_tan": dict(name="64xTân", hp=1500, speed=60, gold=12, dmg=10, color=(200, 20, 20), size=25, mini_boss=True, desc="MINI BOSS: Mỗi 50 HP mất triệu hồi 1 Tân thường"),
    "thu_khoa_cbn": dict(name="ThuKhoaCBN", hp=2000, speed=65, gold=15, dmg=10, color=(150, 50, 200), size=26, mini_boss=True, desc="MINI BOSS: Giảm 25% sát thương tướng xung quanh (phạm vi 100)"),
    "uryu": dict(name="Uryu", hp=5000, speed=70, gold=25, dmg=20, color=(220, 20, 220), size=30, boss=True, desc="BOSS: Gọi 5 Tân yếu mỗi 50 HP mất; gọi 10 Tân mạnh khi <1000 HP"),
    "sieu_cho": dict(name="SIÊU CHÓ", hp=10000, speed=50, gold=100, dmg=100, color=(255, 215, 0), size=36, final_boss=True, desc="FINAL BOSS: Giảm 25% tầm & dame toàn đồ. Triệu hồi liên tục!"),
}


def build_wave(stage, extra_enemies=None):
    q = []
    if stage == 10:
        q = ["64x_ngoc_tan"]
    elif stage == 20:
        q = ["thu_khoa_cbn"]
    elif stage == 25:
        q = ["uryu"]
    elif stage == 30:
        q = ["sieu_cho"]
    else:
        num_enemies = 6 + stage * 2
        for _ in range(num_enemies):
            if stage >= 22:
                choices = ["ngoc_tan_suc_vat", "ngoc_tan_pha_game", "ngoc_tan_cho_dien", "ngoc_tan_gay", "ngoc_tan_nhan_ban"]
            elif stage >= 15:
                choices = ["ngoc_tan_trau", "ngoc_tan_pha_game", "ngoc_tan_cho_dien", "ngoc_tan_lo", "ngoc_tan_nhanh"]
            elif stage >= 8:
                choices = ["ngoc_tan_trau", "ngoc_tan_nhanh", "ngoc_tan_phe", "ngoc_tan_lo"]
            elif stage >= 4:
                choices = ["ngoc_tan_nhanh", "ngoc_tan_phe", "ngoc_tan_trau"]
            else:
                choices = ["ngoc_tan_phe", "ngoc_tan_nhanh"]
            q.append(random.choice(choices))
        
        if stage in (7, 14, 18, 22, 28):
            q.append(random.choice(["64x_ngoc_tan", "thu_khoa_cbn"]))
            
    if extra_enemies:
        q.extend(extra_enemies)
    return q


# ----------------------------------------------------------------------------
# TIỆN ÍCH
# ----------------------------------------------------------------------------
_img_cache = {}


def load_img(path, size):
    key = (path, size)
    if key in _img_cache:
        return _img_cache[key]
    img = None
    if os.path.exists(path):
        try:
            img = pygame.image.load(path).convert_alpha()
            img = pygame.transform.smoothscale(img, size)
        except Exception as ex:
            print("Không đọc được ảnh", path, ex)
    _img_cache[key] = img
    return img


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def cell_center(c):
    return (c[0] * CELL + CELL // 2, c[1] * CELL + CELL // 2)


def build_path():
    cells = []
    cell_set = set()
    for (a, b) in zip(WAYPOINTS, WAYPOINTS[1:]):
        x, y = a
        while (x, y) != b:
            if (x, y) not in cell_set:
                cells.append((x, y))
                cell_set.add((x, y))
            x += (b[0] > x) - (b[0] < x)
            y += (b[1] > y) - (b[1] < y)
        if b not in cell_set:
            cells.append(b)
            cell_set.add(b)
    pts = [(-30, cell_center(WAYPOINTS[0])[1])] + [cell_center(c) for c in WAYPOINTS]
    cum = [0.0]
    for p, q in zip(pts, pts[1:]):
        cum.append(cum[-1] + dist(p, q))
    return cell_set, pts, cum, cells


PATH_CELLS, PATH_PTS, PATH_CUM, PATH_ORDERED_CELLS = build_path()
PATH_LEN = PATH_CUM[-1]


def pos_on_path(d):
    d = max(0, min(d, PATH_LEN))
    for i in range(1, len(PATH_CUM)):
        if d <= PATH_CUM[i]:
            seg = PATH_CUM[i] - PATH_CUM[i - 1]
            t = (d - PATH_CUM[i - 1]) / seg if seg else 0
            a, b = PATH_PTS[i - 1], PATH_PTS[i]
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
    return PATH_PTS[-1]


def weighted_unit(min_rarity=0):
    pool = [u for u in UNITS if u["r"] >= min_rarity]
    weights = [RARITIES[u["r"]][1] for u in pool]
    return random.choices(pool, weights)[0]


def draw_text(surf, text, font, color, x, y, maxw=None, center=False):
    lines = []
    if maxw:
        for para in str(text).split("\n"):
            cur = ""
            for w in para.split(" "):
                t = (cur + " " + w).strip()
                if font.size(t)[0] <= maxw:
                    cur = t
                else:
                    lines.append(cur)
                    cur = w
            lines.append(cur)
    else:
        lines = str(text).split("\n")
    for ln in lines:
        img = font.render(ln, True, color)
        r = img.get_rect()
        if center:
            r.midtop = (x, y)
        else:
            r.topleft = (x, y)
        surf.blit(img, r)
        y += font.get_linesize()
    return y


def make_font(size, bold=False):
    fdir = os.path.join(ASSET_DIR, "fonts")
    for name in (("font_bold.ttf", "font.ttf") if bold else ("font.ttf",)):
        path = os.path.join(fdir, name)
        if os.path.exists(path):
            try:
                return pygame.font.Font(path, size)
            except Exception:
                pass
    for name in ("arial", "segoeui", "tahoma", "dejavusans", "notosans"):
        path = pygame.font.match_font(name, bold=bold)
        if path:
            return pygame.font.Font(path, size)
    return pygame.font.Font(None, size + 6)


def star_points(cx, cy, r):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * 0.45
        pts.append((cx + math.cos(ang) * rr, cy + math.sin(ang) * rr))
    return pts


# ----------------------------------------------------------------------------
# ĐỐI TƯỢNG GAME
# ----------------------------------------------------------------------------
class Unit:
    def __init__(self, d, level=1):
        self.d = d
        self.level = level
        self.enchant = None
        self.timer = random.random() * 0.3
        self.wall_hp = d.get("wall_hp", 15 if d["id"] == "hai_duong" else 0)
        self.skill_cd = 0.0          # CD skill
        self.skill_duration = 0.0    # Thời gian hiệu lực skill
        self.stun_t = 0.0            # Thời gian bị choáng
        self.attack_count = 0        # Đếm đòn đánh (cho Bách Toán)
        self.avatar_override = None  # Avatar tạm thời khi dùng skill (Hoàng Hải z, Khánh Duy z)

    @property
    def rarity(self):
        return RARITIES[self.d["r"]]

    def base_range(self):
        if self.d["id"] == "chan_hung" and self.level == 4:
            return 200
        return self.d["range"] * (1 + 0.1 * (self.level - 1))

    def dmg(self, game=None, cell=None):
        if self.d["dmg"] == 0:
            return 0
        if self.d["id"] == "bach_toan":
            # 15 + (level-1)*2
            base_d = 15 + (self.level - 1) * 2
        else:
            base_d = self.d["dmg"] * (2 ** (self.level - 1))

        buff_mult, _, _, _ = game.get_unit_buffs(self, cell) if (game and cell) else (1.0, 1.0, False, 1.0)
        v = base_d * buff_mult
        if self.enchant == "power":
            v *= 1.5
        return v

    def range(self, game=None, cell=None):
        base_r = self.base_range()
        _, range_mult, _, _ = game.get_unit_buffs(self, cell) if (game and cell) else (1.0, 1.0, False, 1.0)
        return base_r * range_mult

    def cooldown(self, game=None, cell=None):
        if self.d["id"] == "bach_toan":
            c = max(0.1, 0.75 - (self.level - 1) * 0.15)
        else:
            c = self.d["cd"]

        if self.d["id"] == "truong" and self.skill_duration > 0:
            c = 0.5
        if game and cell:
            _, _, _, cd_mult = game.get_unit_buffs(self, cell)
            c *= cd_mult
        if self.enchant == "haste":
            c /= 1.5
        return max(0.1, c)

    def image(self, size):
        img_name = self.avatar_override if self.avatar_override else (self.d["id"] + ".png")
        path = os.path.join(ASSET_DIR, "units", img_name)
        img = load_img(path, (size, size))
        if not img and self.avatar_override:
            img = load_img(os.path.join(ASSET_DIR, "units", self.d["id"] + ".png"), (size, size))
        return img

    def draw(self, surf, center, size, fonts, alpha=255, is_buffed=False):
        x, y = center
        half = size // 2
        
        if is_buffed:
            pygame.draw.circle(surf, (255, 105, 180, 100), (x, y), half + 6, 2)
            pygame.draw.circle(surf, (255, 182, 193), (x, y), half + 8, 1)

        img = self.image(size)
        if img:
            if alpha < 255:
                img = img.copy()
                img.set_alpha(alpha)
            surf.blit(img, (x - half, y - half))
        else:
            pygame.draw.circle(surf, self.d["color"], (x, y), half)
            t = fonts["m"].render(self.d["name"][0], True, (20, 20, 20))
            surf.blit(t, t.get_rect(center=(x, y)))
        pygame.draw.circle(surf, self.rarity[2], (x, y), half + 2, 3)
        
        if not self.d.get("no_upgrade", False):
            for i in range(self.level):
                sx = x - (self.level - 1) * 6 + i * 12
                pygame.draw.polygon(surf, (255, 225, 60), star_points(sx, y + half + 3, 5))
                
        if self.enchant:
            e = ENCHANTS[self.enchant]
            pygame.draw.circle(surf, e[1], (x + half - 2, y - half + 2), 9)
            pygame.draw.circle(surf, (0, 0, 0), (x + half - 2, y - half + 2), 9, 1)
            t = fonts["s"].render(e[2], True, (0, 0, 0))
            surf.blit(t, t.get_rect(center=(x + half - 2, y - half + 2)))
            
        if self.d["id"] == "hai_duong":
            w = 34
            pygame.draw.rect(surf, (60, 0, 0), (x - w // 2, y - half - 8, w, 4))
            pygame.draw.rect(surf, (60, 220, 60), (x - w // 2, y - half - 8, w * max(0, self.wall_hp) / 15.0, 4))
            
        if self.skill_duration > 0:
            pygame.draw.circle(surf, (255, 255, 255), (x, y), half + 4, 2)

        if self.stun_t > 0:
            st_t = fonts["s"].render("STUN", True, (255, 60, 60))
            surf.blit(st_t, st_t.get_rect(center=(x, y - half - 10)))


class Enemy:
    def __init__(self, kind, stage, hp_mult=1.0, speed_mult=1.0):
        self.kind = kind
        self.t = ENEMIES[kind]
        self.max_hp = self.t["hp"] * (HP_SCALE_PER_STAGE ** (stage - 1)) * hp_mult
        self.hp = self.max_hp
        self.speed_mult = speed_mult
        self.d = 0.0
        self.slow = 1.0
        self.slow_t = 0.0
        self.stun_t = 0.0           # Hiệu ứng làm đứng im / choáng quái
        self.burn_dps = 0.0
        self.burn_t = 0.0
        self.burn_owner = None
        self.dead = False
        self.blocked = False
        self.pos = pos_on_path(0)
        self.stun_cooldown = 0.0
        self.last_hp_milestone = self.max_hp  # Cho boss triệu hồi

    def update(self, dt, game):
        if self.burn_t > 0:
            self.burn_t -= dt
            game.damage(self, self.burn_dps * dt, self.burn_owner)
        if self.slow_t > 0:
            self.slow_t -= dt
            if self.slow_t <= 0:
                self.slow = 1.0
        if self.stun_t > 0:
            self.stun_t -= dt
        if self.stun_cooldown > 0:
            self.stun_cooldown -= dt

        speed = self.t["speed"] * self.speed_mult
        if self.kind == "ngoc_tan_cho_dien" and self.hp < (self.max_hp * 0.5):
            speed = 160 * self.speed_mult
            
        if self.blocked or self.stun_t > 0:
            speed = 0.0
        
        self.d += speed * self.slow * dt
        self.pos = pos_on_path(self.d)

        # ---------------- KĨ NĂNG ĐẶC BIỆT CỦA CÁC TÂN ----------------
        # 1. Tân phá: 20% tỉ lệ mỗi 2s làm choáng 1 tướng gần nhất 3s
        if self.kind == "ngoc_tan_pha_game" and not self.dead:
            if not hasattr(self, "skill_timer"): self.skill_timer = 2.0
            self.skill_timer -= dt
            if self.skill_timer <= 0:
                self.skill_timer = 2.0
                if random.random() < 0.2:
                    nearest_u = game.get_nearest_unit_to_pos(self.pos)
                    if nearest_u:
                        nearest_u.stun_t = max(nearest_u.stun_t, 3.0)
                        game.texts.append(["CHOÁNG!", nearest_u_pos[0], nearest_u_pos[1] - 20, 1.0, (255, 60, 60)])

        # 2. Tân stun: gây choáng 1s cho tướng gần nhất mỗi 5s
        if self.kind == "ngoc_tan_lo" and not self.dead:
            if not hasattr(self, "skill_timer"): self.skill_timer = 5.0
            self.skill_timer -= dt
            if self.skill_timer <= 0:
                self.skill_timer = 5.0
                nearest_u = game.get_nearest_unit_to_pos(self.pos, unstunned_only=True)
                if nearest_u:
                    nearest_u.stun_t = max(nearest_u.stun_t, 1.0)

        # 3. Tân gầy: Buff +50% tốc chạy cho Tân khác trong bán kính 1 ô (60px)
        if self.kind == "ngoc_tan_gay" and not self.dead:
            for o in game.enemies:
                if o is not self and not o.dead and dist(self.pos, o.pos) <= CELL:
                    o.speed_mult = max(o.speed_mult, 1.5)

    def draw(self, surf, selected=False):
        x, y = int(self.pos[0]), int(self.pos[1])
        s = self.t["size"]
        if selected:
            pygame.draw.circle(surf, (255, 255, 0), (x, y), s + 5, 2)
        img = load_img(os.path.join(ASSET_DIR, "enemies", self.kind + ".png"), (s * 2 + 6, s * 2 + 6))
        if img:
            surf.blit(img, (x - s - 3, y - s - 3))
        else:
            col = self.t["color"]
            if self.slow < 1:
                col = (min(255, col[0] // 2 + 60), min(255, col[1] // 2 + 100), 255)
            pygame.draw.circle(surf, col, (x, y), s)
            pygame.draw.circle(surf, (0, 0, 0), (x, y), s, 2)
        if self.burn_t > 0:
            pygame.draw.circle(surf, (255, 120, 30), (x, y - s), 4)
        if self.stun_t > 0:
            pygame.draw.circle(surf, (100, 220, 255), (x, y), s + 3, 2)

        w = max(24, s * 2)
        pygame.draw.rect(surf, (60, 0, 0), (x - w // 2, y - s - 10, w, 5))
        pygame.draw.rect(surf, (60, 220, 60), (x - w // 2, y - s - 10, w * max(0, self.hp) / self.max_hp, 5))


class Projectile:
    def __init__(self, pos, target, dmg, unit, is_truong=False, is_anh_ngoc=False, is_tien_quan=False, is_bao_nam=False, is_hoang_hai=False, is_hayuu=False):
        self.pos = list(pos)
        self.target = target
        self.dmg = dmg
        self.unit = unit
        self.color = unit.d["color"]
        self.is_truong = is_truong
        self.is_anh_ngoc = is_anh_ngoc
        self.is_tien_quan = is_tien_quan
        self.is_bao_nam = is_bao_nam
        self.is_hoang_hai = is_hoang_hai
        self.is_hayuu = is_hayuu
        self.alive = True

    def update(self, dt, game):
        if self.target.dead:
            self.alive = False
            return
        tp = self.target.pos
        d = dist(self.pos, tp)
        step = 560 * dt
        if d <= step + 6:
            if self.is_truong:
                game.create_truong_zone(tp)
            elif self.is_hoang_hai:
                game.create_hoang_hai_explosion(tp, self.dmg, self.unit)
            else:
                game.hit(self)
            self.alive = False
        else:
            self.pos[0] += (tp[0] - self.pos[0]) / d * step
            self.pos[1] += (tp[1] - self.pos[1]) / d * step

    def draw(self, surf):
        px, py = int(self.pos[0]), int(self.pos[1])
        if self.is_bao_nam:
            img = load_img(os.path.join(ASSET_DIR, "units", "osu_circle.png"), (30, 30))
            if img:
                surf.blit(img, (px - 15, py - 15))
            else:
                pygame.draw.circle(surf, (255, 140, 200), (px, py), 12)
                pygame.draw.circle(surf, (255, 255, 255), (px, py), 12, 2)
        elif self.is_tien_quan:
            img = load_img(os.path.join(ASSET_DIR, "units", "bong.png"), (18, 18))
            if img:
                surf.blit(img, (px - 9, py - 9))
            else:
                pygame.draw.circle(surf, (255, 255, 255), (px, py), 7)
                pygame.draw.circle(surf, (0, 0, 0), (px, py), 7, 1)
        elif self.is_anh_ngoc:
            img = load_img(os.path.join(ASSET_DIR, "units", "set.png"), (20, 20))
            if img:
                surf.blit(img, (px - 10, py - 10))
            else:
                pygame.draw.circle(surf, (255, 240, 60), (px, py), 7)
        elif self.is_hayuu:
            pygame.draw.circle(surf, (100, 220, 200), (px, py), 8)
            pygame.draw.circle(surf, (255, 255, 255), (px, py), 8, 2)
        else:
            pygame.draw.circle(surf, self.color, (px, py), 6)
            pygame.draw.circle(surf, (255, 255, 255), (px, py), 6, 1)


class WhiteZone:
    def __init__(self, cells, duration=1.0):
        self.cells = cells
        self.duration = duration

    def update(self, dt, game):
        self.duration -= dt
        for e in game.enemies:
            if e.dead:
                continue
            e_cell = (int(e.pos[0] // CELL), int(e.pos[1] // CELL))
            if e_cell in self.cells:
                game.damage(e, 10 * dt, None)
                e.slow = min(e.slow, 0.5)
                e.slow_t = max(e.slow_t, 0.2)


class SpecialEffect:
    def __init__(self, kind, pos, duration, extra=None):
        self.kind = kind
        self.pos = list(pos)
        self.duration = duration
        self.extra = extra or {}
        self.alive = True

    def update(self, dt, game):
        self.duration -= dt
        if self.duration <= 0:
            self.alive = False
            owner_unit = self.extra.get("owner_unit")
            if owner_unit:
                if self.kind == "king_chess_back":
                    owner_unit.skill_cd = 20.0
                elif self.kind == "hoang_hai_skill":
                    owner_unit.avatar_override = None
                elif self.kind == "khanh_duy_skill":
                    owner_unit.avatar_override = None
            return
        
        if self.kind == "king_chess_back":
            self.extra["d_pos"] = max(0.0, self.extra.get("d_pos", PATH_LEN) - 80 * dt)
            self.pos = pos_on_path(self.extra["d_pos"])
            for e in game.enemies:
                if not e.dead and dist(self.pos, e.pos) <= 30:
                    game.damage(e, 10 * dt, None)
            if self.extra["d_pos"] <= 0:
                self.alive = False
                owner_unit = self.extra.get("owner_unit")
                if owner_unit:
                    owner_unit.skill_cd = 20.0

        elif self.kind == "reindeer_run":
            e = self.extra.get("enemy")
            if e and not e.dead:
                e.d = max(0, e.d - 250 * dt)
                e.pos = pos_on_path(e.d)
                for o in game.enemies:
                    if o is not e and not o.dead and dist(e.pos, o.pos) <= 30:
                        game.damage(o, 10 * dt, None)
                if e.d <= 0:
                    e.dead = True
                    self.alive = False

        elif self.kind == "an_smoke":
            for e in game.enemies:
                if not e.dead and dist(self.pos, e.pos) <= 160:
                    game.damage(e, 10 * dt, None)

        elif self.kind == "bao_nam_wheel":
            r_val = self.extra.get("range", 140)
            for e in game.enemies:
                if not e.dead and dist(self.pos, e.pos) <= r_val:
                    game.damage(e, 10 * dt, None)

        elif self.kind == "thor_strike":
            for e in game.enemies:
                if not e.dead:
                    game.damage(e, 5 * dt, None)
                    e.slow = min(e.slow, 0.8)
                    e.slow_t = max(e.slow_t, 0.2)

    def draw(self, surf):
        px, py = int(self.pos[0]), int(self.pos[1])
        if self.kind == "king_chess_back":
            img = load_img(os.path.join(ASSET_DIR, "units", "co.png"), (36, 36))
            if img:
                surf.blit(img, (px - 18, py - 18))
            else:
                pygame.draw.rect(surf, (255, 215, 0), (px - 14, py - 14, 28, 28))
                pygame.draw.polygon(surf, (200, 50, 50), [(px - 14, py - 14), (px + 14, py - 14), (px, py - 26)])

        elif self.kind == "an_smoke":
            pygame.draw.circle(surf, (80, 200, 120, 80), (px, py), 160, 3)

        elif self.kind == "bao_nam_wheel":
            r_val = self.extra.get("range", 140)
            w_img = load_img(os.path.join(ASSET_DIR, "units", "visual_wheel.png"), (r_val * 2, r_val * 2))
            if w_img:
                surf.blit(w_img, (px - r_val, py - r_val))
            else:
                pygame.draw.circle(surf, (255, 140, 200, 90), (px, py), r_val, 3)

        elif self.kind == "thor_strike":
            bua_img = load_img(os.path.join(ASSET_DIR, "units", "bua.png"), (64, 64))
            set_img = load_img(os.path.join(ASSET_DIR, "units", "set.png"), (80, 80))
            if bua_img:
                surf.blit(bua_img, (MAP_W // 2 - 32, MAP_H // 2 - 32))
            if set_img:
                surf.blit(set_img, (px - 40, py - 40))
            else:
                pygame.draw.circle(surf, (255, 230, 50, 100), (px, py), 40, 2)


# ----------------------------------------------------------------------------
# GAME
# ----------------------------------------------------------------------------
class Game:
    def __init__(self, screen):
        self.screen = screen
        self.fonts = {
            "s": make_font(14),
            "m": make_font(16, True),
            "l": make_font(22, True),
            "xl": make_font(44, True),
        }
        self.bg = load_img(os.path.join(ASSET_DIR, "bg", "map.png"), (MAP_W, MAP_H))
        self.auto_sell_list = {u["id"]: False for u in UNITS}
        self.used_codes = set()
        self.code_input_text = ""
        
        # Dev Edit Mode
        self.dev_mode = False
        self.dev_selected_unit_idx = 0
        self.dev_selected_unit_lvl = 1
        self.dev_selected_enemy_idx = 0
        
        # Tan enemy global buffs
        self.tan_hp_mult = 1.0
        self.tan_speed_mult = 1.0
        self.next_wave_extra_enemies = []
        self.aura_pulse = 0.0
        
        self.reset()

    def reset(self):
        self.state = "play"
        self.stage = 1
        self.base_hp = START_BASE_HP
        self.gold = START_GOLD
        self.gems = START_GEMS
        self.dmg_buff = 1.0
        self.range_buff = 1.0        # Sửa lỗi buff tầm xa
        self.auto_merge = False
        self.auto_roll = False
        self.show_auto_sell_modal = False
        self.show_donate_modal = False
        self.show_code_modal = False
        self.show_skills_modal = False
        self.bench = [None] * BENCH_SIZE
        self.board = {}
        self.enemies = []
        self.projs = []
        self.white_zones = []
        self.special_effects = []
        self.fx = []
        self.texts = []
        self.queue = []
        self.spawn_t = 0.0
        self.wave_active = False
        self.selected = None
        self.selected_enemy = None
        self.drag = None
        self.speed = 1
        self.paused = False
        self.msg = ""
        self.msg_t = 0.0
        self.rewards = []
        self.last_clear = (0, 0)
        
        self.tan_hp_mult = 1.0
        self.tan_speed_mult = 1.0
        self.next_wave_extra_enemies = []
        
        self.update_buttons()
        
        bench_w = MAP_W - 30
        cell_gap = 4
        slot_size = (bench_w - (BENCH_SIZE - 1) * cell_gap) // BENCH_SIZE
        self.bench_rects = [pygame.Rect(15 + i * (slot_size + cell_gap), MAP_H + 68, slot_size, slot_size)
                            for i in range(BENCH_SIZE)]
        
        self.add_to_bench(Unit(UNIT_BY_ID["an"]))
        self.add_to_bench(Unit(UNIT_BY_ID["tuan_loc"]))

    def get_nearest_unit_to_pos(self, pos, unstunned_only=False):
        best_u, best_d = None, 999999.0
        for c, u in self.board.items():
            if unstunned_only and u.stun_t > 0:
                continue
            u_p = cell_center(c)
            d_val = dist(pos, u_p)
            if d_val < best_d:
                best_d = d_val
                best_u = u
        return best_u

    def get_unit_buffs(self, u, cell=None):
        if u is None or cell is None:
            return self.dmg_buff, self.range_buff, False, 1.0

        u_pos = cell_center(cell)
        extra_dmg = 0.0
        extra_range = 0.0
        cd_mult = 1.0
        is_buffed = False

        # 1. Duy Anh Buffs (ƯU TIÊN SỬ THI - RARITY 2)
        duy_anh_dmg = 0.0
        duy_anh_range = 0.0
        for c, d_unit in self.board.items():
            if d_unit.d["id"] == "duy_anh" and d_unit.stun_t <= 0:
                if d_unit is not u:
                    d_pos = cell_center(c)
                    d_rng = d_unit.base_range()
                    if dist(u_pos, d_pos) <= d_rng:
                        val = 0.10 * d_unit.level
                        duy_anh_dmg = max(duy_anh_dmg, val)
                        duy_anh_range = max(duy_anh_range, val)
                        is_buffed = True

                if d_unit.level == MAX_LEVEL and d_unit.skill_duration > 0:
                    duy_anh_dmg = max(duy_anh_dmg, 0.20)
                    duy_anh_range = max(duy_anh_range, 0.20)
                    cd_mult *= 0.8
                    is_buffed = True

        extra_dmg += duy_anh_dmg
        extra_range += duy_anh_range

        # 2. Minh Thái Buffs (HIẾM - RARITY 1)
        # QUY TẮC PHÂN BIỆT: Nếu đang nhận BUFF của Duy Anh (Sử thi > Hiếm) -> BỎ QUA BUFF Minh Thái!
        if duy_anh_dmg == 0.0:
            minh_thai_dmg = 0.0
            adj_cells = [
                (cell[0], cell[1] - 1),
                (cell[0], cell[1] + 1),
                (cell[0] - 1, cell[1]),
                (cell[0] + 1, cell[1])
            ]
            for ac in adj_cells:
                m_unit = self.board.get(ac)
                if m_unit and m_unit.d["id"] == "minh_thai" and m_unit.stun_t <= 0:
                    vals = [0.10, 0.12, 0.15, 0.20]
                    val = vals[min(m_unit.level - 1, 3)]
                    minh_thai_dmg = max(minh_thai_dmg, val)
                    is_buffed = True
            extra_dmg += minh_thai_dmg

        dmg_mult = self.dmg_buff + extra_dmg
        range_mult = self.range_buff + extra_range
        return dmg_mult, range_mult, is_buffed, cd_mult

    def get_roll_cost(self):
        return BASE_ROLL_COST + (self.stage - 1) * 5

    def update_buttons(self):
        self.btn = {
            "roll": pygame.Rect(PANEL_X + 15, 85, 210, 32),
            "start": pygame.Rect(PANEL_X + 15, 122, 210, 32),
            "speed": pygame.Rect(PANEL_X + 15, 158, 98, 26),
            "pause": pygame.Rect(PANEL_X + 127, 158, 98, 26),
            "auto_merge": pygame.Rect(PANEL_X + 15, 188, 210, 24),
            "auto_roll": pygame.Rect(PANEL_X + 15, 216, 210, 24),
            "auto_sell": pygame.Rect(PANEL_X + 15, 244, 210, 24),
            "skills_panel": pygame.Rect(PANEL_X + 15, 272, 210, 24),
            "donate": pygame.Rect(PANEL_X + 15, 300, 98, 24),
            "code": pygame.Rect(PANEL_X + 127, 300, 98, 24),
            "use_skill": pygame.Rect(PANEL_X + 15, 592, 210, 34),
            "enchant": pygame.Rect(PANEL_X + 15, 630, 210, 34),
            "sell": pygame.Rect(PANEL_X + 15, 668, 210, 34),
        }

    def say(self, text, t=2.0):
        self.msg, self.msg_t = text, t

    def get_unit(self, slot):
        if slot is None:
            return None
        return self.bench[slot[1]] if slot[0] == "bench" else self.board.get(slot[1])

    def set_unit(self, slot, u):
        if slot[0] == "bench":
            self.bench[slot[1]] = u
        elif u is None:
            self.board.pop(slot[1], None)
        else:
            self.board[slot[1]] = u

    def count_units_on_board_by_id(self, uid):
        return sum(1 for u in self.board.values() if u.d["id"] == uid)

    def add_to_bench(self, u):
        if self.auto_sell_list.get(u.d["id"]):
            val = 8 * (2 ** (u.level - 1)) * (u.d["r"] + 1) if not u.d.get("no_upgrade") else 4
            self.gold += val
            self.texts.append(["+%d (Auto-Sell)" % val, MAP_W // 2, MAP_H // 2, 1.0, (255, 215, 0)])
            return True

        for i in range(BENCH_SIZE):
            if self.bench[i] is None:
                self.bench[i] = u
                if self.auto_merge:
                    self.do_auto_merge()
                return True
        return False

    def do_auto_merge(self):
        merged = True
        while merged:
            merged = False
            for i in range(BENCH_SIZE):
                u1 = self.bench[i]
                if not u1 or u1.level >= MAX_LEVEL or u1.d.get("no_upgrade", False):
                    continue
                for j in range(i + 1, BENCH_SIZE):
                    u2 = self.bench[j]
                    if u2 and u2.d["id"] == u1.d["id"] and u2.level == u1.level:
                        u1.level += 1
                        if u2.enchant and not u1.enchant:
                            u1.enchant = u2.enchant
                        self.bench[j] = None
                        merged = True
                        c = self.bench_rects[i].center
                        self.texts.append(["AUTO MERGE!", c[0], c[1] - 20, 1.0, (255, 230, 80)])
                        break
                if merged:
                    break

    def slot_at(self, pos):
        for i, r in enumerate(self.bench_rects):
            if r.collidepoint(pos):
                return ("bench", i)
        if 0 <= pos[0] < MAP_W and 0 <= pos[1] < MAP_H:
            c = (pos[0] // CELL, pos[1] // CELL)
            return ("board", c)
        return None

    def slot_center(self, slot):
        if slot[0] == "bench":
            return self.bench_rects[slot[1]].center
        return cell_center(slot[1])

    def roll(self):
        if self.state != "play":
            return
        cost = self.get_roll_cost()
        if self.gold < cost:
            return self.say("Không đủ vàng!")
        if all(self.bench):
            return self.say("Kho đồ đã đầy!")
        self.gold -= cost
        u = Unit(weighted_unit())
        self.add_to_bench(u)
        self.say("Triệu hồi: %s (%s)" % (u.d["name"], u.rarity[0]))

    def start_wave(self):
        if self.state != "play" or self.wave_active:
            return
        self.queue = build_wave(self.stage, self.next_wave_extra_enemies)
        self.next_wave_extra_enemies = []
        self.spawn_t = 0
        self.wave_active = True
        
        # SIÊU CHÓ: Khi xuất hiện giảm 25% tầm và dame toàn bộ tướng
        if "sieu_cho" in self.queue:
            self.dmg_buff *= 0.75
            self.range_buff *= 0.75
            self.say("⚠️ SIÊU CHÓ xuất hiện: Giảm 25% Sát thương và Tầm đánh toàn đội!", 3.0)

        minh_duc_units = [u for u in self.board.values() if u.d["id"] == "minh_duc"]
        minh_duc_count = min(len(minh_duc_units), 4)
        total_gold = 0
        for i in range(minh_duc_count):
            u = minh_duc_units[i]
            total_gold += u.d["gold_gen"][min(u.level - 1, 3)]
        
        if total_gold > 0:
            self.gold += total_gold
            self.texts.append(["+%d Vàng (%d Minh Đức)" % (total_gold, minh_duc_count), MAP_W // 2, 80, 1.8, (255, 215, 0)])

    def enchant_selected(self):
        u = self.get_unit(self.selected)
        if not u:
            return
        if u.d.get("no_enchant", False):
            return self.say("Tướng này không thể phù phép!")
        if self.gems < ENCHANT_COST:
            return self.say("Không đủ đá phù phép!")
        choices = [k for k in ENCHANTS if k != u.enchant]
        u.enchant = random.choice(choices)
        self.gems -= ENCHANT_COST
        self.say("Phù phép: " + ENCHANTS[u.enchant][0])

    def sell_selected(self):
        u = self.get_unit(self.selected)
        if not u:
            return
        value = 8 * (2 ** (u.level - 1)) * (u.d["r"] + 1) if not u.d.get("no_upgrade") else 4
        self.gold += value
        self.set_unit(self.selected, None)
        self.selected = None
        self.say("Đã bán, nhận %d vàng" % value)

    def trigger_unit_skill(self, u):
        if u.level < MAX_LEVEL or u.skill_cd > 0 or u.stun_t > 0:
            return
        uid = u.d["id"]
        if uid == "truong":
            u.skill_duration = 5.0
            u.skill_cd = 20.0
            self.say("Trường: Cuồng kích tốc độ 0.5s/bắn!")

        elif uid == "duy_anh":
            u.skill_duration = 10.0
            u.skill_cd = 30.0
            self.say("Duy Anh: Toàn đội +20% dame & +20% tầm!")

        elif uid == "huy_duc":
            self.special_effects.append(SpecialEffect("king_chess_back", pos_on_path(PATH_LEN), 99.0, {
                "d_pos": PATH_LEN,
                "owner_unit": u
            }))
            u.skill_cd = 999.0
            self.say("Huy Đức: Quân Vua càn quét từ Nhà!")

        elif uid == "anh_ngoc":
            u.skill_cd = 60.0
            for e in self.enemies:
                if not e.dead:
                    self.damage(e, 75, u)
                    e.slow = min(e.slow, 0.8)
                    e.slow_t = max(e.slow_t, 5.0)
            self.special_effects.append(SpecialEffect("thor_strike", (MAP_W // 2, MAP_H // 2), 5.0))
            self.say("Anh Ngọc: Búa Thor giáng sét toàn bản đồ!")

        elif uid == "khanh_duy":
            u.skill_duration = 5.0
            u.skill_cd = 30.0
            u.avatar_override = "khanh_duyz.png"
            self.special_effects.append(SpecialEffect("khanh_duy_skill", (0, 0), 5.0, {"owner_unit": u}))
            
            cell_found = [c for c, un in self.board.items() if un is u]
            c = cell_center(cell_found[0]) if cell_found else (0, 0)
            converted = 0
            for e in self.enemies:
                if not e.dead and dist(c, e.pos) <= u.range(self, cell_found[0] if cell_found else None) and e.hp < 1000:
                    e.dead = True
                    converted += 1
            self.say("Khánh Duy: Thu phục %d Tân làm đồng minh!" % converted)

        elif uid == "hoang_hai":
            u.skill_duration = 1.0
            u.skill_cd = 10.0
            u.avatar_override = "hoang_haiz.png"
            self.special_effects.append(SpecialEffect("hoang_hai_skill", (0, 0), 1.0, {"owner_unit": u}))
            for e in self.enemies:
                if not e.dead and e.kind == "ngoc_tan_gay":
                    e.stun_t = max(e.stun_t, 1.0)
            self.say("Hoàng Hải: Làm choáng toàn bộ Tân gầy trong 1s!")

    def drop(self, src, dst):
        u = self.get_unit(src)
        if u is None or dst is None or dst == src:
            return

        if self.wave_active:
            if src[0] == "board":
                self.say("Không thể di chuyển tướng đã đặt trên bản đồ khi đang trong trận!")
                return
            if dst[0] == "board":
                t = self.get_unit(dst)
                if t is not None:
                    is_same_type = (t.d["id"] == u.d["id"])
                    can_merge = (is_same_type and not u.d.get("no_upgrade", False) and t.level == u.level and t.level < MAX_LEVEL)
                    if not can_merge:
                        self.say("Không thể tráo đổi vị trí tướng trên bản đồ khi đang trong trận!")
                        return

        if dst[0] == "board":
            c = dst[1]
            is_path = c in PATH_CELLS
            is_hai_duong = (u.d["id"] == "hai_duong")
            if is_hai_duong and not is_path:
                self.say("Hải Dương phải được đặt TRÊN ĐƯỜNG ĐỊCH đi!")
                return
            if not is_hai_duong and is_path:
                self.say("Tướng thường không được đặt trên đường đi!")
                return

            current_on_board = self.count_units_on_board_by_id(u.d["id"])
            dest_unit = self.get_unit(dst)
            is_same_swap = dest_unit and dest_unit.d["id"] == u.d["id"]
            if src[0] == "bench" and current_on_board >= MAX_UNITS_PER_TYPE_ON_BOARD and not is_same_swap:
                self.say("Tối đa chỉ được đặt 4 tướng loại %s trên bản đồ!" % u.d["name"])
                return

        t = self.get_unit(dst)
        if t is None:
            self.set_unit(dst, u)
            self.set_unit(src, None)
            self.selected = dst
        elif t and u and t.d["id"] == u.d["id"]:
            if u.d.get("no_upgrade", False):
                self.say("Hải Dương không thể nâng cấp!")
                return
            if t.level == u.level and t.level < MAX_LEVEL:
                t.level += 1
                if u.enchant and (not t.enchant):
                    t.enchant = u.enchant
                self.set_unit(src, None)
                self.selected = dst
                self.say("MERGE! %s lên cấp %d" % (t.d["name"], t.level))
                c = self.slot_center(dst)
                self.texts.append(["LEVEL UP!", c[0], c[1] - 30, 1.2, (255, 230, 80)])
            else:
                self.set_unit(dst, u)
                self.set_unit(src, t)
                self.selected = dst
        else:
            if dst[0] == "board" and src[0] == "board":
                if (u.d["id"] == "hai_duong" and dst[1] not in PATH_CELLS) or (t and t.d["id"] == "hai_duong" and src[1] not in PATH_CELLS):
                    self.say("Vị trí đổi không phù hợp cho Hải Dương!")
                    return
            self.set_unit(dst, u)
            self.set_unit(src, t)
            self.selected = dst

    def damage(self, e, amount, owner):
        if e.dead:
            return
        
        # ThuKhoaCBN (Boss): Giảm 25% sát thương nhận vào từ tướng xung quanh
        if owner:
            for boss in self.enemies:
                if not boss.dead and boss.kind == "thu_khoa_cbn" and dist(boss.pos, e.pos) <= 100:
                    amount *= 0.75
                    break

        e.hp -= amount

        # Mini boss & Boss Triggers
        hp_lost = e.last_hp_milestone - e.hp
        if hp_lost >= 50:
            count = int(hp_lost // 50)
            e.last_hp_milestone -= count * 50
            if e.kind == "64x_ngoc_tan":
                for _ in range(count):
                    self.spawn_sub_enemy("ngoc_tan_phe", e.pos)
            elif e.kind == "uryu":
                for _ in range(count * 5):
                    self.spawn_sub_enemy("ngoc_tan_rac", e.pos)

        if e.kind == "uryu" and e.hp <= 1000 and not getattr(e, "uryu_triggered", False):
            e.uryu_triggered = True
            for _ in range(10):
                self.spawn_sub_enemy("ngoc_tan_suc_vat", e.pos)

        if e.kind == "sieu_cho":
            if hp_lost >= 100:
                c_100 = int(hp_lost // 100)
                for _ in range(c_100):
                    self.spawn_sub_enemy("ngoc_tan_lo", e.pos)
            if e.hp <= 1000 and not getattr(e, "sieu_cho_1000", False):
                e.sieu_cho_1000 = True
                self.say("SIÊU CHÓ: Triệu hồi liên tục Tân thường!", 2.0)
            if e.hp <= 500 and not getattr(e, "sieu_cho_500", False):
                e.sieu_cho_500 = True
                for _ in range(3):
                    self.spawn_sub_enemy("64x_ngoc_tan", e.pos)

        if e.hp <= 0:
            e.dead = True
            if self.selected_enemy == e:
                self.selected_enemy = None

            # SỬA LỖI TÂN KHÁC / TÂN NHÂN BẢN
            if e.kind == "ngoc_tan_nhanh" or e.kind == "ngoc_tan_lo":
                self.spawn_sub_enemy("ngoc_tan_phe", e.pos)

            elif e.kind == "ngoc_tan_nhan_ban":
                child_hp = math.floor(e.max_hp / 2.0)
                if child_hp > 1:
                    for _ in range(2):
                        child = Enemy("ngoc_tan_nhan_ban", self.stage, hp_mult=1.0, speed_mult=e.speed_mult + 0.08)
                        child.max_hp = child_hp
                        child.hp = child_hp
                        child.d = e.d
                        child.pos = list(e.pos)
                        self.enemies.append(child)

            # Cộng vàng (+ Hoàng Hải LV4 bonus + Greed enchant)
            hoang_hai_bonus = sum(1 for u in self.board.values() if u.d["id"] == "hoang_hai" and u.level == MAX_LEVEL)
            g = e.t["gold"] + (3 if owner and owner.enchant == "greed" else 0) + hoang_hai_bonus
            self.gold += g
            self.texts.append(["+%d" % g, e.pos[0], e.pos[1] - 10, 0.8, (255, 220, 60)])

    def spawn_sub_enemy(self, kind, pos):
        sub = Enemy(kind, self.stage, self.tan_hp_mult, self.tan_speed_mult)
        sub.pos = list(pos)
        sub.d = max(0, dist(pos, pos_on_path(0)))
        self.enemies.append(sub)

    def hit(self, p):
        e, u = p.target, p.unit
        dmg = p.dmg
        
        if u.d["id"] == "gia_nam" and u.level == 4:
            r = random.random()
            if r < 0.2:
                self.texts.append(["MISS", e.pos[0], e.pos[1] - 15, 0.6, (200, 200, 200)])
                return
            elif r < 0.7:
                dmg *= 2.0

        if u.d["id"] == "bach_toan":
            u.attack_count += 1
            if u.level == 4 and u.attack_count % 5 == 0:
                dmg *= 2.0
                self.texts.append(["CRIT x2!", e.pos[0], e.pos[1] - 18, 0.8, (255, 230, 80)])
                
        if u.d["id"] == "khoa_nguyen":
            e.d = max(0.0, e.d - CELL)
            if u.level == 4 and u.skill_cd <= 0:
                if random.random() < 0.5:
                    u.skill_cd = 30.0
                    e_cell = (int(e.pos[0] // CELL), int(e.pos[1] // CELL))
                    for o in self.enemies:
                        if not o.dead and (int(o.pos[0] // CELL), int(o.pos[1] // CELL)) == e_cell:
                            o.d = max(0.0, o.d - CELL * 2)

        if u.d["id"] == "tien_quan":
            e.slow = min(e.slow, 0.7)
            e.slow_t = max(e.slow_t, 0.75)

        if u.d["id"] == "hayuu":
            e.stun_t = max(e.stun_t, 1.5)

        if u.d["id"] == "anh_ngoc":
            for o in self.enemies:
                if not o.dead and o is not e and dist(e.pos, o.pos) <= 30:
                    self.damage(o, dmg * 0.7, u)

        if u.d.get("execute_hp") and e.hp <= u.d["execute_hp"]:
            dmg = e.hp + 999
            
        self.damage(e, dmg, u)
        
        if u.enchant == "ice":
            self.apply_slow(e, 0.6, 1.5)
        if u.d.get("burn") or u.enchant == "fire":
            e.burn_dps = max(e.burn_dps, dmg * 0.35)
            e.burn_t = 3.0
            e.burn_owner = u

    def create_truong_zone(self, pos):
        c_x, c_y = int(pos[0] // CELL), int(pos[1] // CELL)
        hit_cells = {(c_x, c_y)}
        for c in PATH_ORDERED_CELLS:
            if dist(cell_center(c), pos) <= CELL * 1.5:
                hit_cells.add(c)
        self.white_zones.append(WhiteZone(hit_cells, 1.0))

    def create_hoang_hai_explosion(self, pos, dmg, unit):
        c_x, c_y = int(pos[0] // CELL), int(pos[1] // CELL)
        hit_cells = {(c_x, c_y)}
        for c in PATH_ORDERED_CELLS:
            if dist(cell_center(c), pos) <= CELL * 1.5 and len(hit_cells) < 3:
                hit_cells.add(c)
        for e in self.enemies:
            if not e.dead:
                e_cell = (int(e.pos[0] // CELL), int(e.pos[1] // CELL))
                if e_cell in hit_cells:
                    self.damage(e, dmg, unit)

    @staticmethod
    def apply_slow(e, factor, t):
        e.slow = min(e.slow, factor)
        e.slow_t = max(e.slow_t, t)

    def update(self, dt):
        if self.msg_t > 0:
            self.msg_t -= dt
        for t in self.texts:
            t[3] -= dt
            t[2] -= 25 * dt
        self.texts = [t for t in self.texts if t[3] > 0]
        for f in self.fx:
            f[2] -= dt
        self.fx = [f for f in self.fx if f[2] > 0]
        
        self.aura_pulse = (self.aura_pulse + dt * 4.0) % (math.pi * 2)
        
        # Auto-Roll
        if self.auto_roll and self.state == "play":
            if self.gold >= self.get_roll_cost() and not all(self.bench):
                self.roll()

        if self.state != "play" or self.paused:
            return
        dt *= self.speed

        if self.wave_active:
            for cell, u in list(self.board.items()):
                if u.stun_t > 0:
                    u.stun_t -= dt
                if u.skill_cd > 0:
                    u.skill_cd -= dt
                if u.skill_duration > 0:
                    u.skill_duration -= dt

                if u.level == MAX_LEVEL and u.skill_cd <= 0 and u.stun_t <= 0:
                    uid = u.d["id"]
                    if uid == "an":
                        u.skill_duration = 2.0
                        u.skill_cd = 20.0
                        c = cell_center(cell)
                        self.special_effects.append(SpecialEffect("an_smoke", c, 2.0))

                    elif uid == "hayuu":
                        u.skill_cd = 20.0
                        for e in self.enemies:
                            if not e.dead:
                                e.stun_t = max(e.stun_t, 1.0)
                        self.say("Hayuu: Đứng im toàn bộ Tân trong 1s!")

                    elif uid == "bao_nam":
                        u.skill_duration = 5.0
                        u.skill_cd = 20.0
                        c = cell_center(cell)
                        self.special_effects.append(SpecialEffect("bao_nam_wheel", c, 5.0, {"range": u.range(self, cell), "owner_unit": u}))

                    elif uid == "tuan_loc":
                        u.skill_cd = 20.0
                        c = cell_center(cell)
                        in_rng = [e for e in self.enemies if not e.dead and dist(c, e.pos) <= u.range(self, cell)]
                        if in_rng:
                            target_e = random.choice(in_rng)
                            self.special_effects.append(SpecialEffect("reindeer_run", target_e.pos, 5.0, {"enemy": target_e}))

                    elif uid == "chan_hung":
                        u.skill_cd = 20.0
                        c = cell_center(cell)
                        in_rng = [e for e in self.enemies if not e.dead and dist(c, e.pos) <= 200]
                        if in_rng:
                            best_e = max(in_rng, key=lambda x: x.hp)
                            self.damage(best_e, 100, u)

                    elif uid == "tien_quan":
                        u.skill_cd = 20.0
                        c = cell_center(cell)
                        in_rng = [e for e in self.enemies if not e.dead and dist(c, e.pos) <= u.range(self, cell)]
                        if in_rng:
                            best_e = random.choice(in_rng)
                            for o in self.enemies:
                                if not o.dead and dist(best_e.pos, o.pos) <= 100:
                                    self.damage(o, 40, u)

                    elif uid == "minh_thai":
                        u.skill_cd = 45.0
                        left_cell = (cell[0] - 1, cell[1])
                        right_cell = (cell[0] + 1, cell[1])
                        for adj in (left_cell, right_cell):
                            target_u = self.board.get(adj)
                            if target_u and target_u.d["r"] <= 2 and target_u.level == MAX_LEVEL and target_u.d["id"] != "anh_ngoc":
                                target_u.skill_cd = 0.0
                                c_target = cell_center(adj)
                                self.texts.append(["SKILL RESET!", c_target[0], c_target[1] - 25, 1.5, (120, 255, 120)])

        if self.wave_active and self.queue:
            self.spawn_t -= dt
            if self.spawn_t <= 0:
                self.enemies.append(Enemy(self.queue.pop(0), self.stage, self.tan_hp_mult, self.tan_speed_mult))
                self.spawn_t = 0.75

        hai_duong_cells = {c: u for c, u in self.board.items() if u.d["id"] == "hai_duong"}
        for e in self.enemies:
            if e.dead:
                continue
            e_cell = (int(e.pos[0] // CELL), int(e.pos[1] // CELL))
            if e_cell in hai_duong_cells:
                e.blocked = True
            else:
                e.blocked = False
            e.update(dt, self)

        for cell, u in list(hai_duong_cells.items()):
            blocked_enemies = [e for e in self.enemies if not e.dead and (int(e.pos[0] // CELL), int(e.pos[1] // CELL)) == cell]
            if blocked_enemies:
                total_enemy_dmg = sum(e.t["dmg"] for e in blocked_enemies)
                u.wall_hp -= total_enemy_dmg * dt
                if u.wall_hp <= 0:
                    self.board.pop(cell, None)
                    for e in blocked_enemies:
                        e.blocked = False
                    self.say("Hải Dương đã bị vỡ chặn!")

        for e in self.enemies:
            if not e.dead and e.d >= PATH_LEN:
                e.dead = True
                self.base_hp -= e.t["dmg"]
                self.say("Nhà bị tấn công! -%d máu" % e.t["dmg"], 1.0)
        self.enemies = [e for e in self.enemies if not e.dead]

        # TƯỚNG TẤN CÔNG
        all_units = [(c, u) for c, u in self.board.items()]
        for c, u in all_units:
            if u.stun_t > 0:
                continue

            # TƯỚNG KHÁNH DUY: ĐÁNH ĐA MỤC TIÊU BẰNG AURA HÀO QUANG (KHÔNG BẮN ĐẠN)
            if u.d["id"] == "khanh_duy":
                u.timer -= dt
                if u.timer <= 0:
                    u.timer = u.cooldown(self, c)
                    pos = cell_center(c)
                    rng = u.range(self, c)
                    dmg_val = u.dmg(self, c)
                    for e in self.enemies:
                        if not e.dead and dist(pos, e.pos) <= rng:
                            self.damage(e, dmg_val, u)
                continue

            # Bỏ qua các tướng không tấn công trực tiếp
            if u.d["id"] == "hai_duong" or u.d["dmg"] == 0:
                continue

            u.timer -= dt
            if u.timer > 0:
                continue
            pos = cell_center(c)
            rng = u.range(self, c)
            
            # Hayuu bắn được N Tân tùy theo level (LV1: 1, LV2: 2, LV3: 3, LV4: 4)
            if u.d["id"] == "hayuu":
                targets = [e for e in self.enemies if not e.dead and dist(pos, e.pos) <= rng]
                targets.sort(key=lambda x: x.d, reverse=True)
                targets = targets[:u.level]
                if targets:
                    for tgt in targets:
                        self.projs.append(Projectile(pos, tgt, u.dmg(self, c), u, is_hayuu=True))
                    u.timer = u.cooldown(self, c)
                continue

            # Bảo Nam bắn 3 osu_circle trong 0.5s
            if u.d["id"] == "bao_nam":
                best = None
                for e in self.enemies:
                    if not e.dead and dist(pos, e.pos) <= rng:
                        if best is None or e.d > best.d:
                            best = e
                if best:
                    for delay_idx in range(3):
                        self.projs.append(Projectile(pos, best, u.dmg(self, c), u, is_bao_nam=True))
                    u.timer = u.cooldown(self, c)
                continue

            best = None
            for e in self.enemies:
                if not e.dead and dist(pos, e.pos) <= rng:
                    if best is None or e.d > best.d:
                        best = e
            if best:
                is_truong = (u.d["id"] == "truong")
                is_anh_ngoc = (u.d["id"] == "anh_ngoc")
                is_tien_quan = (u.d["id"] == "tien_quan")
                is_hoang_hai = (u.d["id"] == "hoang_hai")
                self.projs.append(Projectile(pos, best, u.dmg(self, c), u, is_truong, is_anh_ngoc, is_tien_quan, is_hoang_hai=is_hoang_hai))
                u.timer = u.cooldown(self, c)

        for p in self.projs:
            p.update(dt, self)
        self.projs = [p for p in self.projs if p.alive]

        for wz in self.white_zones:
            wz.update(dt, self)
        self.white_zones = [wz for wz in self.white_zones if wz.duration > 0]

        for se in self.special_effects:
            se.update(dt, self)
        self.special_effects = [se for se in self.special_effects if se.alive]

        self.enemies = [e for e in self.enemies if not e.dead]

        if self.base_hp <= 0:
            self.state = "gameover"
        elif self.wave_active and not self.queue and not self.enemies:
            self.finish_stage()

    def finish_stage(self):
        self.wave_active = False
        self.projs.clear()
        self.white_zones.clear()
        bonus_g = 25 + self.stage * 5
        bonus_gem = 1 + (1 if self.stage % 3 == 0 else 0)
        self.gold += bonus_g
        self.gems += bonus_gem
        self.last_clear = (bonus_g, bonus_gem)
        if self.stage >= MAX_STAGE:
            self.state = "victory"
            return

        pool = [
            ("Túi vàng", "+%d Vàng" % (60 + self.stage * 10), "gold", "Phe Tân: Màn sau thêm 10 Tân thường", "extra_10_phe"),
            ("Đá phù phép", "+3 Đá Phù Phép", "gems", "Phe Tân: +10% Máu (vĩnh viễn)", "tan_hp"),
            ("Triệu hồi Hiếm+", "Nhận 1 Tướng Hiếm trở lên", "unit1", "Phe Tân: +10% Tốc chạy (vĩnh viễn)", "tan_speed"),
            ("Hồi máu nhà", "+5 Máu cho Nhà", "heal", "Phe Tân: Màn sau thêm 15 Tân thường", "extra_15_phe"),
            ("Quân lệnh", "+10% Dame Tướng (vĩnh viễn)", "buff", "Phe Tân: +10% Máu (vĩnh viễn)", "tan_hp"),
            ("Tầm nhìn", "+10% Tầm Tướng (vĩnh viễn)", "range_buff", "Phe Tân: +10% Tốc chạy (vĩnh viễn)", "tan_speed"),
        ]
        self.rewards = random.sample(pool, 3)
        self.state = "reward"

    def claim_reward(self, idx):
        reward = self.rewards[idx]
        kind, tan_kind = reward[2], reward[4]

        if kind == "gold":
            self.gold += 60 + self.stage * 10
        elif kind == "gems":
            self.gems += 3
        elif kind == "unit1":
            self.give_unit(weighted_unit(1))
        elif kind == "heal":
            self.base_hp = min(START_BASE_HP, self.base_hp + 5)
        elif kind == "buff":
            self.dmg_buff += 0.10
        elif kind == "range_buff":
            # SỬA LỖI: TĂNG TẦM NHÌN CHO TOÀN BỘ TƯỚNG VĨNH VIỄN
            self.range_buff += 0.10
            self.say("Đã tăng +10% Tầm đánh vĩnh viễn cho tất cả tướng!")

        if tan_kind == "extra_10_phe":
            self.next_wave_extra_enemies.extend(["ngoc_tan_phe"] * 10)
        elif tan_kind == "extra_15_phe":
            self.next_wave_extra_enemies.extend(["ngoc_tan_phe"] * 15)
        elif tan_kind == "tan_hp":
            self.tan_hp_mult += 0.10
        elif tan_kind == "tan_speed":
            self.tan_speed_mult += 0.10

        self.stage += 1
        self.update_buttons()
        self.state = "play"

    def redeem_code(self, code_str):
        code_clean = code_str.strip()
        if len(code_clean) != 5:
            return self.say("Code phải bao gồm đúng 5 ký tự!")
        if code_clean in self.used_codes:
            return self.say("Code này đã được sử dụng trước đó!")
        
        if code_clean in CODES_REWARDS:
            reward_type, val = CODES_REWARDS[code_clean]
            self.used_codes.add(code_clean)
            if reward_type == "gold":
                self.gold += val
                self.say("Nhập Code thành công! Nhận +%d Vàng" % val)
            elif reward_type == "gems":
                self.gems += val
                self.say("Nhập Code thành công! Nhận +%d Đá Phù Phép" % val)
            elif reward_type == "unit_kd":
                u = Unit(UNIT_BY_ID["khanh_duy"], level=val)
                self.give_unit(u.d)
                # Đảm bảo level đúng nếu add thành công
                for b_u in reversed(self.bench):
                    if b_u and b_u.d["id"] == "khanh_duy":
                        b_u.level = val
                        break
                self.say("Nhập Code thành công! Nhận 1 Khánh Duy LV%d" % val)
            self.show_code_modal = False
            self.code_input_text = ""
        else:
            self.say("Code không tồn tại hoặc không hợp lệ!")

    def give_unit(self, d):
        if not self.add_to_bench(Unit(d)):
            self.gold += 40
            self.say("Kho đầy - quy đổi thành 40 vàng")

    def on_mouse_down(self, pos, button):
        if self.state in ("gameover", "victory"):
            self.reset()
            return
        if self.state == "reward":
            for i, r in enumerate(self.reward_rects()):
                if r.collidepoint(pos):
                    self.claim_reward(i)
            return

        if self.show_donate_modal:
            close_btn = pygame.Rect(W // 2 - 60, H - 90, 120, 38)
            if close_btn.collidepoint(pos):
                self.show_donate_modal = False
            return

        if self.show_code_modal:
            close_btn = pygame.Rect(W // 2 - 140, H // 2 + 60, 120, 38)
            submit_btn = pygame.Rect(W // 2 + 20, H // 2 + 60, 120, 38)
            if close_btn.collidepoint(pos):
                self.show_code_modal = False
            elif submit_btn.collidepoint(pos):
                self.redeem_code(self.code_input_text)
            return

        if self.show_skills_modal:
            active_units = [(c, u) for c, u in self.board.items()
                            if u.level == MAX_LEVEL and u.d["id"] in ("truong", "duy_anh", "huy_duc", "anh_ngoc", "khanh_duy", "hoang_hai")]
            for idx, (c, u) in enumerate(active_units):
                btn_r = pygame.Rect(W // 2 + 110, 160 + idx * 45, 120, 32)
                if btn_r.collidepoint(pos):
                    self.trigger_unit_skill(u)
                    return
            close_btn = pygame.Rect(W // 2 - 60, H - 80, 120, 38)
            if close_btn.collidepoint(pos):
                self.show_skills_modal = False
            return

        if self.show_auto_sell_modal:
            grid_rects = self.get_auto_sell_grid_rects()
            for uid, r in grid_rects.items():
                if r.collidepoint(pos):
                    self.auto_sell_list[uid] = not self.auto_sell_list[uid]
                    return
            close_btn = pygame.Rect(W // 2 - 60, H - 90, 120, 38)
            if close_btn.collidepoint(pos):
                self.show_auto_sell_modal = False
            return

        if self.dev_mode:
            dev_rects = self.get_dev_ui_rects()
            if dev_rects["prev_u"].collidepoint(pos):
                self.dev_selected_unit_idx = (self.dev_selected_unit_idx - 1) % len(UNITS)
                return
            if dev_rects["next_u"].collidepoint(pos):
                self.dev_selected_unit_idx = (self.dev_selected_unit_idx + 1) % len(UNITS)
                return
            if dev_rects["lvl_u"].collidepoint(pos):
                self.dev_selected_unit_lvl = (self.dev_selected_unit_lvl % MAX_LEVEL) + 1
                return
            if dev_rects["add_bench"].collidepoint(pos):
                u_info = UNITS[self.dev_selected_unit_idx]
                self.add_to_bench(Unit(u_info, self.dev_selected_unit_lvl))
                self.say("Dev: Đã thêm %s LV%d vào Kho" % (u_info["name"], self.dev_selected_unit_lvl))
                return
            if dev_rects["prev_e"].collidepoint(pos):
                e_keys = list(ENEMIES.keys())
                self.dev_selected_enemy_idx = (self.dev_selected_enemy_idx - 1) % len(e_keys)
                return
            if dev_rects["next_e"].collidepoint(pos):
                e_keys = list(ENEMIES.keys())
                self.dev_selected_enemy_idx = (self.dev_selected_enemy_idx + 1) % len(e_keys)
                return
            if dev_rects["spawn_e"].collidepoint(pos):
                e_key = list(ENEMIES.keys())[self.dev_selected_enemy_idx]
                self.enemies.append(Enemy(e_key, self.stage, self.tan_hp_mult, self.tan_speed_mult))
                self.wave_active = True
                self.say("Dev: Đã tạo %s" % ENEMIES[e_key]["name"])
                return
            if dev_rects["prev_stage"].collidepoint(pos):
                self.stage = max(1, self.stage - 1)
                return
            if dev_rects["next_stage"].collidepoint(pos):
                self.stage = min(MAX_STAGE, self.stage + 1)
                return
            if dev_rects["clear_e"].collidepoint(pos):
                self.enemies.clear()
                self.queue.clear()
                self.wave_active = False
                self.say("Dev: Đã dọn sạch quái!")
                return
            if dev_rects["add_gold"].collidepoint(pos):
                self.gold += 500
                self.gems += 20
                return

        if button == 3:
            self.selected = None
            self.selected_enemy = None
            return
        if button != 1:
            return
        b = self.btn
        if b["roll"].collidepoint(pos):
            return self.roll()
        if b["start"].collidepoint(pos):
            return self.start_wave()
        if b["speed"].collidepoint(pos):
            self.speed = {1: 2, 2: 3, 3: 1}[self.speed]
            return
        if b["pause"].collidepoint(pos):
            self.paused = not self.paused
            return
        if b["auto_merge"].collidepoint(pos):
            self.auto_merge = not self.auto_merge
            if self.auto_merge:
                self.do_auto_merge()
                self.say("Đã BẬT Tự động Merge!")
            else:
                self.say("Đã TẮT Tự động Merge.")
            return
        if b["auto_roll"].collidepoint(pos):
            self.auto_roll = not self.auto_roll
            if self.auto_roll:
                self.say("Đã BẬT Tự động Roll!")
            else:
                self.say("Đã TẮT Tự động Roll.")
            return
        if b["auto_sell"].collidepoint(pos):
            self.show_auto_sell_modal = True
            return
        if b["skills_panel"].collidepoint(pos):
            self.show_skills_modal = True
            return
        if b["donate"].collidepoint(pos):
            self.show_donate_modal = True
            return
        if b["code"].collidepoint(pos):
            self.show_code_modal = True
            self.code_input_text = ""
            return
        if b["enchant"].collidepoint(pos):
            return self.enchant_selected()
        if b["sell"].collidepoint(pos):
            return self.sell_selected()
        if b["use_skill"].collidepoint(pos):
            u = self.get_unit(self.selected)
            if u:
                self.trigger_unit_skill(u)
            return

        clicked_enemy = None
        for e in self.enemies:
            if dist(pos, e.pos) <= e.t["size"] + 6:
                clicked_enemy = e
                break
        if clicked_enemy:
            self.selected_enemy = clicked_enemy
            self.selected = None
            return

        slot = self.slot_at(pos)
        if slot and self.get_unit(slot):
            self.drag = dict(src=slot, start=pos, moved=False)
            self.selected = slot
            self.selected_enemy = None
        elif slot:
            self.selected = None
            self.selected_enemy = None

    def on_mouse_up(self, pos, button):
        if button != 1 or not self.drag:
            return
        d, self.drag = self.drag, None
        if d["moved"]:
            self.drop(d["src"], self.slot_at(pos))

    def on_mouse_move(self, pos):
        if self.drag and not self.drag["moved"] and dist(pos, self.drag["start"]) > 6:
            self.drag["moved"] = True

    def on_key(self, key, mods, unicode_char=""):
        if (mods & pygame.KMOD_CTRL) and (mods & pygame.KMOD_ALT) and key == pygame.K_x:
            self.dev_mode = not self.dev_mode
            status = "BẬT" if self.dev_mode else "TẮT"
            self.say("CHẾ ĐỘ CHỈNH SỬA (DEV MODE): %s" % status)
            return

        if self.show_code_modal:
            if key == pygame.K_BACKSPACE:
                self.code_input_text = self.code_input_text[:-1]
            elif key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.redeem_code(self.code_input_text)
            elif len(self.code_input_text) < 5 and unicode_char and unicode_char.isprintable():
                self.code_input_text += unicode_char
            return

        if key == pygame.K_SPACE:
            self.start_wave()
        elif key == pygame.K_p:
            self.paused = not self.paused
        elif key == pygame.K_r:
            self.reset()
        elif key == pygame.K_q:
            self.roll()
        elif key == pygame.K_m:
            self.auto_merge = not self.auto_merge
        elif key == pygame.K_a:
            self.auto_roll = not self.auto_roll

    def reward_rects(self):
        return [pygame.Rect(120 + i * 270, 180, 250, 320) for i in range(3)]

    def get_auto_sell_grid_rects(self):
        rects = {}
        start_x, start_y = W // 2 - 320, 150
        for i, u_info in enumerate(UNITS):
            row = i // 4
            col = i % 4
            r = pygame.Rect(start_x + col * 155, start_y + row * 100, 145, 90)
            rects[u_info["id"]] = r
        return rects

    def get_dev_ui_rects(self):
        y = 10
        return {
            "prev_u": pygame.Rect(10, y, 30, 24),
            "next_u": pygame.Rect(180, y, 30, 24),
            "lvl_u": pygame.Rect(215, y, 65, 24),
            "add_bench": pygame.Rect(285, y, 90, 24),
            "prev_e": pygame.Rect(10, y + 28, 30, 24),
            "next_e": pygame.Rect(180, y + 28, 30, 24),
            "spawn_e": pygame.Rect(215, y + 28, 90, 24),
            "prev_stage": pygame.Rect(310, y + 28, 30, 24),
            "next_stage": pygame.Rect(345, y + 28, 30, 24),
            "clear_e": pygame.Rect(380, y + 28, 70, 24),
            "add_gold": pygame.Rect(380, y, 70, 24),
        }

    def draw(self):
        s = self.screen
        s.fill((24, 26, 34))
        self.draw_map(s)
        self.draw_bench(s)
        self.draw_panel(s)
        
        if self.dev_mode:
            self.draw_dev_ui(s)

        mouse = pygame.mouse.get_pos()
        sel = self.get_unit(self.selected)
        if sel and self.selected and self.selected[0] == "board" and sel.range(self, self.selected[1]) > 0:
            c = cell_center(self.selected[1])
            self.draw_range(s, c, sel.range(self, self.selected[1]))
        if self.drag and self.drag["moved"]:
            u = self.get_unit(self.drag["src"])
            if u:
                tgt = self.slot_at(mouse)
                if tgt and tgt[0] == "board" and u.range(self, tgt[1]) > 0:
                    self.draw_range(s, cell_center(tgt[1]), u.range(self, tgt[1]))
                u.draw(s, mouse, ICON, self.fonts, 200)
        for t in self.texts:
            img = self.fonts["m"].render(t[0], True, t[4])
            s.blit(img, img.get_rect(center=(t[1], t[2])))
        if self.msg_t > 0:
            img = self.fonts["l"].render(self.msg, True, (255, 255, 255))
            r = img.get_rect(center=(MAP_W // 2, MAP_H + 28))
            s.blit(img, r)

        if self.show_donate_modal:
            self.draw_donate_modal(s)
        elif self.show_code_modal:
            self.draw_code_modal(s)
        elif self.show_skills_modal:
            self.draw_skills_modal(s)
        elif self.show_auto_sell_modal:
            self.draw_auto_sell_modal(s)
        elif self.state == "reward":
            self.draw_reward(s)
        elif self.state in ("gameover", "victory"):
            self.draw_end(s)
        pygame.display.flip()

    @staticmethod
    def draw_range(s, c, r):
        surf = pygame.Surface((int(r * 2) + 4, int(r * 2) + 4), pygame.SRCALPHA)
        pygame.draw.circle(surf, (255, 255, 255, 40), (int(r) + 2, int(r) + 2), int(r))
        pygame.draw.circle(surf, (255, 255, 255, 160), (int(r) + 2, int(r) + 2), int(r), 2)
        s.blit(surf, (c[0] - r - 2, c[1] - r - 2))

    def draw_map(self, s):
        clip = s.get_clip()
        s.set_clip((0, 0, MAP_W, MAP_H))
        if self.bg:
            s.blit(self.bg, (0, 0))
        else:
            for cx in range(COLS):
                for cy in range(ROWS):
                    col = (70, 130, 70) if (cx + cy) % 2 == 0 else (64, 122, 64)
                    pygame.draw.rect(s, col, (cx * CELL, cy * CELL, CELL, CELL))
            for c in PATH_CELLS:
                pygame.draw.rect(s, (160, 125, 80), (c[0] * CELL, c[1] * CELL, CELL, CELL))
                
        for wz in self.white_zones:
            surf_w = pygame.Surface((CELL, CELL), pygame.SRCALPHA)
            surf_w.fill((255, 255, 255, 180))
            for c in wz.cells:
                s.blit(surf_w, (c[0] * CELL, c[1] * CELL))

        # VẼ AURA HÀO QUANG CỦA KHÁNH DUY
        for c, u in self.board.items():
            if u.d["id"] == "khanh_duy":
                center_pos = cell_center(c)
                r_val = int(u.range(self, c))
                pulse_r = r_val + int(math.sin(self.aura_pulse) * 6)
                aura_surf = pygame.Surface((pulse_r * 2 + 8, pulse_r * 2 + 8), pygame.SRCALPHA)
                pygame.draw.circle(aura_surf, (255, 215, 0, 35), (pulse_r + 4, pulse_r + 4), pulse_r)
                pygame.draw.circle(aura_surf, (255, 235, 100, 120), (pulse_r + 4, pulse_r + 4), pulse_r, 2)
                s.blit(aura_surf, (center_pos[0] - pulse_r - 4, center_pos[1] - pulse_r - 4))

        if self.drag and self.drag["moved"]:
            u = self.get_unit(self.drag["src"])
            is_hai_duong = u and (u.d["id"] == "hai_duong")
            for cx in range(COLS):
                for cy in range(ROWS):
                    is_path = (cx, cy) in PATH_CELLS
                    if (cx, cy) not in self.board:
                        if (is_hai_duong and is_path) or (not is_hai_duong and not is_path):
                            pygame.draw.rect(s, (255, 255, 255), (cx * CELL + 2, cy * CELL + 2, CELL - 4, CELL - 4), 1)
        hx, hy = cell_center(WAYPOINTS[-1])
        himg = load_img(os.path.join(ASSET_DIR, "enemies", "home.png"), (CELL, CELL))
        if himg:
            s.blit(himg, (hx - CELL // 2, hy - CELL // 2))
        else:
            pygame.draw.rect(s, (220, 220, 240), (hx - 24, hy - 20, 48, 40))
            pygame.draw.polygon(s, (190, 60, 60), [(hx - 30, hy - 20), (hx + 30, hy - 20), (hx, hy - 44)])
            
        for c, u in self.board.items():
            if self.drag and self.drag["moved"] and self.drag["src"] == ("board", c):
                continue
            _, _, is_buffed, _ = self.get_unit_buffs(u, c)
            u.draw(s, cell_center(c), ICON, self.fonts, is_buffed=is_buffed)
            
        if self.selected and self.selected[0] == "board" and self.get_unit(self.selected):
            r = pygame.Rect(0, 0, CELL, CELL)
            r.center = cell_center(self.selected[1])
            pygame.draw.rect(s, (255, 255, 0), r, 2)
        for e in self.enemies:
            e.draw(s, selected=(e == self.selected_enemy))
        for p in self.projs:
            p.draw(s)
        for se in self.special_effects:
            se.draw(s)
        s.set_clip(clip)

    def draw_dev_ui(self, s):
        r = pygame.Rect(5, 5, 455, 58)
        pygame.draw.rect(s, (20, 25, 40, 220), r, border_radius=6)
        pygame.draw.rect(s, (255, 215, 0), r, 2, border_radius=6)
        
        dev_rects = self.get_dev_ui_rects()
        f = self.fonts["s"]
        
        u_info = UNITS[self.dev_selected_unit_idx]
        e_keys = list(ENEMIES.keys())
        e_info = ENEMIES[e_keys[self.dev_selected_enemy_idx]]
        
        pygame.draw.rect(s, (60, 70, 90), dev_rects["prev_u"], border_radius=4)
        draw_text(s, "<", f, (255, 255, 255), dev_rects["prev_u"].centerx, dev_rects["prev_u"].y + 4, center=True)
        draw_text(s, u_info["name"], f, u_info["color"], 105, dev_rects["prev_u"].y + 4, center=True)
        pygame.draw.rect(s, (60, 70, 90), dev_rects["next_u"], border_radius=4)
        draw_text(s, ">", f, (255, 255, 255), dev_rects["next_u"].centerx, dev_rects["next_u"].y + 4, center=True)
        
        pygame.draw.rect(s, (80, 90, 110), dev_rects["lvl_u"], border_radius=4)
        draw_text(s, "LVL %d" % self.dev_selected_unit_lvl, f, (255, 230, 90), dev_rects["lvl_u"].centerx, dev_rects["lvl_u"].y + 4, center=True)
        
        pygame.draw.rect(s, (40, 140, 80), dev_rects["add_bench"], border_radius=4)
        draw_text(s, "+ Kho đồ", f, (255, 255, 255), dev_rects["add_bench"].centerx, dev_rects["add_bench"].y + 4, center=True)
        
        pygame.draw.rect(s, (200, 140, 40), dev_rects["add_gold"], border_radius=4)
        draw_text(s, "+Vàng/Đá", f, (255, 255, 255), dev_rects["add_gold"].centerx, dev_rects["add_gold"].y + 4, center=True)

        pygame.draw.rect(s, (60, 70, 90), dev_rects["prev_e"], border_radius=4)
        draw_text(s, "<", f, (255, 255, 255), dev_rects["prev_e"].centerx, dev_rects["prev_e"].y + 4, center=True)
        draw_text(s, e_info["name"][:12], f, (255, 140, 140), 105, dev_rects["prev_e"].y + 4, center=True)
        pygame.draw.rect(s, (60, 70, 90), dev_rects["next_e"], border_radius=4)
        draw_text(s, ">", f, (255, 255, 255), dev_rects["next_e"].centerx, dev_rects["next_e"].y + 4, center=True)
        
        pygame.draw.rect(s, (180, 60, 60), dev_rects["spawn_e"], border_radius=4)
        draw_text(s, "Spawn Quái", f, (255, 255, 255), dev_rects["spawn_e"].centerx, dev_rects["spawn_e"].y + 4, center=True)
        
        pygame.draw.rect(s, (60, 70, 90), dev_rects["prev_stage"], border_radius=4)
        draw_text(s, "-M", f, (255, 255, 255), dev_rects["prev_stage"].centerx, dev_rects["prev_stage"].y + 4, center=True)
        pygame.draw.rect(s, (60, 70, 90), dev_rects["next_stage"], border_radius=4)
        draw_text(s, "+M", f, (255, 255, 255), dev_rects["next_stage"].centerx, dev_rects["next_stage"].y + 4, center=True)
        
        pygame.draw.rect(s, (120, 60, 160), dev_rects["clear_e"], border_radius=4)
        draw_text(s, "Xóa Quái", f, (255, 255, 255), dev_rects["clear_e"].centerx, dev_rects["clear_e"].y + 4, center=True)

    def draw_bench(self, s):
        pygame.draw.rect(s, (36, 38, 50), (0, MAP_H, MAP_W, H - MAP_H))
        draw_text(s, "Kho đồ (12 ô) | M: Auto-Merge, A: Auto-Roll",
                  self.fonts["s"], (170, 175, 190), 20, MAP_H + 8)
        draw_text(s, "Q: Roll | Space: Bắt đầu màn | P: Tạm dừng", self.fonts["s"], (120, 125, 140), 20, MAP_H + 26)
        for i, r in enumerate(self.bench_rects):
            pygame.draw.rect(s, (50, 53, 70), r, border_radius=6)
            u = self.bench[i]
            sel = self.selected == ("bench", i)
            pygame.draw.rect(s, (255, 255, 0) if sel else (80, 84, 105), r, 2, border_radius=6)
            if u and not (self.drag and self.drag["moved"] and self.drag["src"] == ("bench", i)):
                u.draw(s, (r.centerx, r.centery - 2), SLOT - 12, self.fonts)

    def button(self, s, key, text, enabled=True, color=(70, 120, 200)):
        r = self.btn[key]
        pygame.draw.rect(s, color if enabled else (70, 70, 80), r, border_radius=6)
        pygame.draw.rect(s, (255, 255, 255) if enabled else (100, 100, 110), r, 2, border_radius=6)
        img = self.fonts["m"].render(text, True, (255, 255, 255) if enabled else (150, 150, 150))
        s.blit(img, img.get_rect(center=r.center))

    def draw_panel(self, s):
        pygame.draw.rect(s, (30, 32, 44), (PANEL_X, 0, W - PANEL_X, H))
        f = self.fonts
        x = PANEL_X + 15
        draw_text(s, "Màn %d / %d" % (self.stage, MAX_STAGE), f["l"], (255, 255, 255), x, 6)
        draw_text(s, "Nhà: %d / %d" % (max(0, int(self.base_hp)), START_BASE_HP), f["m"], (255, 120, 120), x, 30)
        draw_text(s, "Vàng: %d" % self.gold, f["m"], (255, 220, 70), x, 48)
        draw_text(s, "Đá phù phép: %d" % self.gems, f["m"], (140, 210, 255), x, 66)
        draw_text(s, "ST x%.1f | Tầm x%.1f" % (self.dmg_buff, self.range_buff), f["s"], (180, 180, 200), x + 100, 48)
        
        roll_c = self.get_roll_cost()
        can_roll = self.gold >= roll_c and self.state == "play"
        self.button(s, "roll", "ROLL TƯỚNG (%d vàng)" % roll_c, can_roll, (60, 150, 90))
        if self.wave_active:
            left = len(self.queue) + len(self.enemies)
            self.button(s, "start", "Còn %d quái..." % left, False)
        else:
            self.button(s, "start", "BẮT ĐẦU MÀN %d" % self.stage, self.state == "play", (200, 90, 70))
        self.button(s, "speed", "Tốc độ x%d" % self.speed)
        self.button(s, "pause", "Tiếp tục" if self.paused else "Tạm dừng")
        
        self.button(s, "auto_merge", "Auto Merge: " + ("BẬT" if self.auto_merge else "TẮT"), True, (40, 160, 220) if self.auto_merge else (90, 95, 110))
        self.button(s, "auto_roll", "Auto Roll: " + ("BẬT" if self.auto_roll else "TẮT"), True, (220, 140, 40) if self.auto_roll else (90, 95, 110))
        self.button(s, "auto_sell", "Auto-Sell: CẤU HÌNH", True, (160, 70, 180))
        self.button(s, "skills_panel", "KĨ NĂNG TƯỚNG (ACTIVE)", True, (220, 110, 40))
        self.button(s, "donate", "DONATE QR", True, (220, 80, 140))
        self.button(s, "code", "NHẬP CODE", True, (50, 180, 120))

        y = 330
        pygame.draw.rect(s, (40, 43, 58), (PANEL_X + 10, y - 4, 220, 256), border_radius=8)
        
        u = self.get_unit(self.selected)
        e = self.selected_enemy
        
        if e:
            y = draw_text(s, e.t["name"], f["l"], (255, 100, 100), x, y)
            y = draw_text(s, "KẺ ĐỊCH", f["s"], (220, 180, 180), x, y + 2)
            y = draw_text(s, e.t.get("desc", ""), f["s"], (230, 200, 170), x, y + 4, 205)
            y += 4
            y = draw_text(s, "Máu: %d / %d" % (max(0, int(e.hp)), int(e.max_hp)), f["m"], (255, 255, 255), x, y)
            y = draw_text(s, "ST nhà: %d" % e.t["dmg"], f["m"], (255, 255, 255), x, y)
            y = draw_text(s, "Tốc độ: %d" % int(e.t["speed"] * e.speed_mult), f["m"], (255, 255, 255), x, y)
            y = draw_text(s, "Thưởng: +%d vàng" % e.t["gold"], f["m"], (255, 215, 0), x, y)
        elif u:
            y = draw_text(s, u.d["name"], f["l"], u.rarity[2], x, y)
            y = draw_text(s, "%s  -  Cấp %d/%d" % (u.rarity[0], u.level, MAX_LEVEL), f["s"], (200, 200, 210), x, y + 2)
            y = draw_text(s, u.d["desc"], f["s"], (170, 220, 170), x, y + 4, 205)
            y += 4
            if u.d["id"] == "hai_duong":
                y = draw_text(s, "Máu riêng: %.1f / 15" % max(0, u.wall_hp), f["m"], (255, 255, 255), x, y)
            else:
                cell_pos = self.selected[1] if (self.selected and self.selected[0] == "board") else None
                dmg_val = int(u.dmg(self, cell_pos))
                rng_val = int(u.range(self, cell_pos))
                _, _, is_buffed, _ = self.get_unit_buffs(u, cell_pos)
                
                y = draw_text(s, "Sát thương: %d" % dmg_val, f["m"], (255, 255, 255), x, y)
                y = draw_text(s, "Tầm đánh: %d" % rng_val, f["m"], (255, 255, 255), x, y)
                if is_buffed:
                    y = draw_text(s, "(Đang nhận Buff!)", f["s"], (255, 105, 180), x, y)
                if u.cooldown(self, cell_pos) < 90:
                    y = draw_text(s, "Tốc đánh: %.1f/s" % (1 / u.cooldown(self, cell_pos)), f["m"], (255, 255, 255), x, y)
            if u.level == MAX_LEVEL:
                if u.skill_cd > 0:
                    y = draw_text(s, "Skill hồi: %.1fs" % u.skill_cd, f["m"], (255, 140, 140), x, y + 2)
                else:
                    y = draw_text(s, "Skill SẴN SÀNG!", f["m"], (120, 255, 120), x, y + 2)
        else:
            draw_text(s, "Click vào Tướng hoặc Kẻ Địch để xem thông tin chỉ số.", f["s"], (150, 155, 170), x, y, 205)
        
        has = u is not None
        can_use_skill = has and u.level == MAX_LEVEL and u.skill_cd <= 0 and u.d["id"] in ("truong", "duy_anh", "huy_duc", "anh_ngoc", "khanh_duy", "hoang_hai")
        self.button(s, "use_skill", "KÍCH HOẠT SKILL (LV4)", can_use_skill, (240, 140, 40))
        
        can_enchant = has and (not u.d.get("no_enchant", False)) and (self.gems >= ENCHANT_COST)
        self.button(s, "enchant", "PHÙ PHÉP (%d đá)" % ENCHANT_COST, can_enchant, (140, 80, 200))
        
        sell_v = 8 * (2 ** (u.level - 1)) * (u.d["r"] + 1) if u and not u.d.get("no_upgrade") else 4
        self.button(s, "sell", "BÁN (+%d vàng)" % sell_v, has, (150, 80, 80))
        
        if self.paused:
            draw_text(s, "TẠM DỪNG", f["xl"], (255, 255, 255), MAP_W // 2, MAP_H // 2 - 22, center=True)

    def draw_overlay(self, s, alpha=170):
        o = pygame.Surface((W, H), pygame.SRCALPHA)
        o.fill((0, 0, 0, alpha))
        s.blit(o, (0, 0))

    def draw_donate_modal(self, s):
        self.draw_overlay(s, 220)
        f = self.fonts
        draw_text(s, "ỦNG HỘ TÁC GIẢ (DONATE QR)", f["xl"], (255, 230, 90), W // 2, 40, center=True)
        draw_text(s, "Cảm ơn bạn đã ủng hộ phát triển Tân Tower Defense!", f["m"], (200, 210, 230), W // 2, 95, center=True)
        
        qr_path = os.path.join(ASSET_DIR, "bg", "donateqr.png")
        qr_img = load_img(qr_path, (320, 320))
        if qr_img:
            s.blit(qr_img, (W // 2 - 160, 140))
        else:
            r_box = pygame.Rect(W // 2 - 160, 140, 320, 320)
            pygame.draw.rect(s, (40, 45, 60), r_box, border_radius=12)
            pygame.draw.rect(s, (255, 215, 0), r_box, 2, border_radius=12)
            draw_text(s, "Chưa tìm thấy ảnh QR:\nassets/bg/donateqr.png", f["m"], (255, 140, 140), W // 2, 280, center=True)

        close_btn = pygame.Rect(W // 2 - 60, H - 90, 120, 38)
        pygame.draw.rect(s, (70, 130, 200), close_btn, border_radius=8)
        draw_text(s, "ĐÓNG", f["m"], (255, 255, 255), close_btn.centerx, close_btn.y + 8, center=True)

    def draw_code_modal(self, s):
        self.draw_overlay(s, 220)
        f = self.fonts
        draw_text(s, "NHẬP CODE NHẬN QUÀ", f["xl"], (255, 230, 90), W // 2, 100, center=True)
        draw_text(s, "Nhập mã Code gồm đúng 5 ký tự (phân biệt hoa thường):", f["m"], (200, 210, 230), W // 2, 160, center=True)

        box_r = pygame.Rect(W // 2 - 150, H // 2 - 30, 300, 50)
        pygame.draw.rect(s, (30, 35, 50), box_r, border_radius=8)
        pygame.draw.rect(s, (255, 215, 0) if len(self.code_input_text) == 5 else (100, 110, 140), box_r, 2, border_radius=8)

        txt_show = self.code_input_text + ("_" if (pygame.time.get_ticks() // 500) % 2 == 0 else "")
        draw_text(s, txt_show, f["xl"], (255, 255, 255), box_r.centerx, box_r.y + 2, center=True)

        close_btn = pygame.Rect(W // 2 - 140, H // 2 + 60, 120, 38)
        submit_btn = pygame.Rect(W // 2 + 20, H // 2 + 60, 120, 38)

        pygame.draw.rect(s, (100, 105, 120), close_btn, border_radius=8)
        draw_text(s, "ĐÓNG", f["m"], (255, 255, 255), close_btn.centerx, close_btn.y + 8, center=True)

        can_sub = len(self.code_input_text) == 5
        pygame.draw.rect(s, (40, 180, 100) if can_sub else (60, 70, 80), submit_btn, border_radius=8)
        draw_text(s, "NHẬP", f["m"], (255, 255, 255) if can_sub else (140, 140, 140), submit_btn.centerx, submit_btn.y + 8, center=True)

    def draw_skills_modal(self, s):
        self.draw_overlay(s, 220)
        f = self.fonts
        draw_text(s, "BẢNG KĨ NĂNG CÁC TƯỚNG (ACTIVE SKILLS)", f["xl"], (255, 230, 90), W // 2, 40, center=True)
        draw_text(s, "Kích hoạt trực tiếp kĩ năng cấp 4 của các tướng đang trên bản đồ:", f["m"], (200, 210, 230), W // 2, 95, center=True)

        active_units = [(c, u) for c, u in self.board.items()
                        if u.level == MAX_LEVEL and u.d["id"] in ("truong", "duy_anh", "huy_duc", "anh_ngoc", "khanh_duy", "hoang_hai")]

        if not active_units:
            draw_text(s, "Chưa có tướng LV4 nào có kĩ năng Active trên bản đồ!", f["l"], (255, 140, 140), W // 2, 250, center=True)
        else:
            for idx, (c, u) in enumerate(active_units):
                y_p = 150 + idx * 45
                r_card = pygame.Rect(W // 2 - 320, y_p, 560, 38)
                pygame.draw.rect(s, (45, 50, 70), r_card, border_radius=6)
                pygame.draw.rect(s, u.rarity[2], r_card, 2, border_radius=6)

                pos_txt = "Ô (%d, %d)" % (c[0], c[1])
                draw_text(s, "%s - %s" % (u.d["name"], pos_txt), f["m"], u.rarity[2], r_card.x + 15, y_p + 8)

                if u.skill_cd > 0:
                    status_txt = "Hồi chiêu: %.1fs" % u.skill_cd
                    st_col = (255, 120, 120)
                else:
                    status_txt = "SẴN SÀNG"
                    st_col = (120, 255, 120)
                draw_text(s, status_txt, f["m"], st_col, r_card.x + 220, y_p + 8)

                btn_r = pygame.Rect(W // 2 + 110, y_p + 3, 120, 32)
                can_act = u.skill_cd <= 0 and u.stun_t <= 0
                pygame.draw.rect(s, (240, 140, 40) if can_act else (70, 75, 90), btn_r, border_radius=6)
                draw_text(s, "KÍCH HOẠT", f["s"], (255, 255, 255) if can_act else (140, 140, 140), btn_r.centerx, btn_r.y + 7, center=True)

        close_btn = pygame.Rect(W // 2 - 60, H - 80, 120, 38)
        pygame.draw.rect(s, (70, 130, 200), close_btn, border_radius=8)
        draw_text(s, "ĐÓNG", f["m"], (255, 255, 255), close_btn.centerx, close_btn.y + 8, center=True)

    def draw_auto_sell_modal(self, s):
        self.draw_overlay(s, 210)
        f = self.fonts
        draw_text(s, "CẤU HÌNH TỰ ĐỘNG BÁN TƯỚNG", f["xl"], (255, 230, 90), W // 2, 50, center=True)
        draw_text(s, "Click vào Tướng để Bật/Tắt tự động bán khi xuất hiện trong kho đồ", f["m"], (200, 210, 230), W // 2, 105, center=True)
        
        grid_rects = self.get_auto_sell_grid_rects()
        for u_info in UNITS:
            uid = u_info["id"]
            r = grid_rects[uid]
            is_active = self.auto_sell_list[uid]
            bg_col = (100, 40, 40) if is_active else (45, 50, 70)
            border_col = (255, 80, 80) if is_active else (90, 100, 130)
            
            pygame.draw.rect(s, bg_col, r, border_radius=8)
            pygame.draw.rect(s, border_col, r, 2, border_radius=8)
            
            img = load_img(os.path.join(ASSET_DIR, "units", uid + ".png"), (36, 36))
            if img:
                s.blit(img, (r.x + 8, r.y + 8))
            draw_text(s, u_info["name"], f["m"], RARITIES[u_info["r"]][2], r.x + 50, r.y + 10)
            
            status_txt = "ĐÃ CHỌN BÁN" if is_active else "Giữ lại"
            status_col = (255, 120, 120) if is_active else (140, 220, 140)
            draw_text(s, status_txt, f["s"], status_col, r.x + 10, r.y + 58)
            
        close_btn = pygame.Rect(W // 2 - 60, H - 80, 120, 38)
        pygame.draw.rect(s, (70, 130, 200), close_btn, border_radius=8)
        draw_text(s, "ĐÓNG", f["m"], (255, 255, 255), close_btn.centerx, close_btn.y + 8, center=True)

    def draw_reward(self, s):
        self.draw_overlay(s)
        f = self.fonts
        draw_text(s, "CHINH PHỤC MÀN %d!" % self.stage, f["xl"], (255, 230, 90), W // 2, 40, center=True)
        draw_text(s, "Thưởng cơ bản: +%d vàng, +%d đá phù phép    |    Chọn 1 phần thưởng:" % self.last_clear,
                  f["m"], (230, 230, 240), W // 2, 100, center=True)
        mouse = pygame.mouse.get_pos()
        for r, (title, desc, _k, tan_desc, _tk) in zip(self.reward_rects(), self.rewards):
            hov = r.collidepoint(mouse)
            pygame.draw.rect(s, (70, 80, 120) if hov else (45, 50, 80), r, border_radius=12)
            pygame.draw.rect(s, (255, 230, 90) if hov else (120, 125, 160), r, 3, border_radius=12)
            
            draw_text(s, title, f["l"], (255, 255, 255), r.centerx, r.y + 20, center=True)
            draw_text(s, desc, f["m"], (140, 220, 255), r.x + 15, r.y + 80, r.w - 30)
            
            pygame.draw.line(s, (255, 100, 100), (r.x + 15, r.y + 170), (r.x + r.w - 15, r.y + 170), 2)
            draw_text(s, "⚠️ BUFF PHE TÂN:", f["s"], (255, 100, 100), r.x + 15, r.y + 185)
            draw_text(s, tan_desc, f["m"], (255, 160, 160), r.x + 15, r.y + 210, r.w - 30)

    def draw_end(self, s):
        self.draw_overlay(s, 200)
        f = self.fonts
        if self.state == "victory":
            draw_text(s, "CHIẾN THẮNG TUYỆT ĐỐI!", f["xl"], (255, 230, 90), W // 2, 250, center=True)
            draw_text(s, "Bạn đã bảo vệ thành công qua tất cả %d màn chơi." % MAX_STAGE, f["l"], (255, 255, 255), W // 2, 320, center=True)
        else:
            draw_text(s, "THÀNH ĐÃ THẤT THỦ", f["xl"], (255, 90, 90), W // 2, 250, center=True)
            draw_text(s, "Bạn dừng lại ở màn %d." % self.stage, f["l"], (255, 255, 255), W // 2, 320, center=True)
        draw_text(s, "Click chuột hoặc nhấn R để chơi lại", f["m"], (200, 200, 210), W // 2, 380, center=True)


# ----------------------------------------------------------------------------
async def main():
    pygame.init()
    pygame.display.set_caption("Tân tower defense")
    screen = pygame.display.set_mode((W, H))
    clock = pygame.time.Clock()
    game = Game(screen)
    while True:
        dt = min(clock.tick(60) / 1000.0, 0.05)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                game.on_mouse_down(ev.pos, ev.button)
            elif ev.type == pygame.MOUSEBUTTONUP:
                game.on_mouse_up(ev.pos, ev.button)
            elif ev.type == pygame.MOUSEMOTION:
                game.on_mouse_move(ev.pos)
            elif ev.type == pygame.KEYDOWN:
                game.on_key(ev.key, pygame.key.get_mods(), ev.unicode)
        game.update(dt)
        game.draw()
        
        await asyncio.sleep(0)  # Bắt buộc cho Pygbag / WebAssembly render


if __name__ == "__main__":
    asyncio.run(main())
